# codex-auth on Windows

**결론부터: WSL2 를 써라.** 네이티브 Windows(PowerShell·CMD·Git Bash)에서는 일부만 돌고,
그중 하나는 **계정을 잃을 수 있는** 제약이다. 아래에 무엇이 왜 그런지 전부 적었다.

> 이 문서는 macOS 에서 코드를 읽고 정리한 것이다. **Windows 실기 검증은 하지 않았다** —
> 아래 표의 "동작" 은 코드가 쓰는 시스템 기능을 기준으로 한 판정이고, 실제로 돌려 보면
> 다를 수 있다. 확인되면 `HISTORY.md` 에 실측으로 덧붙여라.

---

## 1. 왜 POSIX 에 묶여 있나

| 기능 | 쓰는 것 | Windows 네이티브 |
|---|---|---|
| 슬롯 저장·전환 (`list`·`use`·`sync`·`adopt`) | node fs 만 | ✅ 돈다 |
| 잔량·사용량 조회 (`quota`·`usage`) | node + `codex app-server` | ✅ 돈다 |
| 계정 추가 (`add`) | `spawnSync("codex", …)` | ⚠️ `codex.cmd` 해석 문제 가능 |
| **전환 가드** (`codex exec` 중 전환 차단) | `ps -Ao pid=,args=` | ❌ **`ps` 가 없다 → 가드가 통째로 꺼진다** |
| **레인** (세션별 계정 격리) | `symlinkSync` | ⚠️ 개발자 모드/관리자 권한 필요 |
| 런처 (`codex` 래핑·자동 재개) | bash 스크립트 | ❌ bash 필요 (Git Bash 로 부분 가능) |
| 파일 권한 0600 | `chmodSync` | ⚠️ 무시됨 — `check` 가 계속 경고 |

### ❌ 가장 중요한 것: 전환 가드가 꺼진다

`codexProcs()` 는 `ps` 출력을 파싱해 **지금 도는 codex** 를 찾는다. Windows 에 `ps` 가 없으면
그 함수가 **빈 배열**을 돌려주고, 코드는 그걸 "도는 codex 가 없다" 로 읽는다. 결과:

- `codex exec` 배치가 도는 중에 계정을 갈아끼운다 → **레인이 account_id 불일치로 줄줄이 죽는다.**
- 토큰 회전 레이스를 못 막는다 → 같은 refresh token 이 두 번 회전하면 OpenAI 의 재사용 탐지가
  **그 계정의 토큰 패밀리를 통째로 폐기한다.** 재로그인 외에 복구 방법이 없다.

즉 Windows 네이티브에서는 "잘 도는 것처럼 보이다가 계정이 죽는" 실패가 열려 있다.
`ps` 가 없으면 안전판이 조용히 사라지고, **조용히 사라진 안전판이 가장 나쁘다.**

---

## 2. 권장: WSL2 (전부 동작)

WSL2 안은 리눅스라 이 문서의 제약이 **하나도** 해당되지 않는다. `ps`·심링크·bash 전부 있다.

```bash
# PowerShell (관리자)
wsl --install -d Ubuntu

# 이후 WSL 안에서 — 리눅스와 완전히 같다
sudo apt update && sudo apt install -y nodejs npm
npm i -g @openai/codex
printf 'cli_auth_credentials_store = "file"\n' >> ~/.codex/config.toml
git clone <this-repo> && cd oh-my-jobdori && ./install.sh
exec $SHELL -l
codex-auth.mjs check
```

**주의: WSL 과 Windows 의 codex 를 섞지 마라.** 둘은 각자 `~/.codex/auth.json` 을 갖는다.
한쪽에서 토큰이 회전하면 다른 쪽 사본은 이미 소비된 refresh token 을 들고 죽는다
(`SKILL.md` 의 "auth.json 을 다른 데로 복사하지 마라" 와 같은 사고다). **한 곳만 쓴다.**

`\\wsl$\...` 경유로 Windows 쪽 `.codex` 를 마운트해 공유하는 것도 같은 이유로 하지 마라.

---

## 3. Git Bash 네이티브 (부분 동작 — 권장하지 않음)

Git for Windows 의 bash 에서는 런처가 **뜨기는 한다.** `mktemp`·`find`·`grep`·`printf` 가 있다.

되는 것:
- `codex-auth.mjs` 의 슬롯 관리 전부 (`list`·`use`·`sync`·`adopt`·`quota`·`usage`·`next`)
- `dscodex.sh` 의 preflight → codex 실행 → write-back 흐름

되지 않거나 위험한 것:
- **전환 가드 없음** (위 §1). `codex exec` 병렬 배치를 절대 돌리지 마라.
- **레인**: `symlinkSync` 가 `EPERM` 을 내면 `laneCreate` 가 실패하고, 런처는 경고 후
  공유 홈으로 뜬다 (`레인을 만들지 못했다 — 공유 홈으로 띄운다`). 즉 **세션 격리가 없다** —
  계정 하나가 소진되면 열어둔 세션이 전부 같이 만료되는 옛 동작으로 돌아간다.
  Windows 설정 → 개발자 모드를 켜면 심링크가 허용된다 (재부팅 필요).
- `check` 의 `권한이 600 이 아니다` 경고: Windows 는 POSIX 모드 비트가 없어 항상 뜬다. **무시해도 된다.**
  대신 슬롯 디렉토리에 NTFS ACL 로 본인만 접근하게 걸어라 — 안 그러면 refresh token 평문이 그대로 노출된다.

  ```powershell
  icacls "$env:USERPROFILE\.config\codex-auth" /inheritance:r /grant:r "$env:USERNAME:(OI)(CI)F"
  ```

셸 진입점은 `~/.bashrc` 에 넣는다 (`install.sh` 가 `$SHELL` 을 보고 자동으로 고른다):

```bash
# omj:begin codex-auth
codex() {
	local launcher="$HOME/.claude/skills/codex-auth/scripts/dscodex.sh"
	if [[ -n "${CODEX_PLAIN:-}" || ! -x "$launcher" ]]; then
		command codex "$@"
	else
		"$launcher" "$@"
	fi
}
dscodex() { codex "$@"; }
# omj:end codex-auth
```

---

## 4. PowerShell (슬롯 관리만)

런처(bash)는 못 쓰지만 `codex-auth.mjs` 는 node 라 그대로 돈다. 계정 전환을 **손으로** 하는 방식이다.

```powershell
$auth = "$env:USERPROFILE\.claude\skills\codex-auth\scripts\codex-auth.mjs"
node $auth list
node $auth quota
node $auth use <slot>     # 전환은 직접
codex                     # 그리고 codex 를 띄운다
```

편하게 쓰려면 `$PROFILE` 에:

```powershell
function codex-auth { node "$env:USERPROFILE\.claude\skills\codex-auth\scripts\codex-auth.mjs" @args }
```

⚠️ 이 경로에는 preflight·레인·자동 재개가 **전혀 없다.** 그리고 전환 가드도 없으므로
**codex 가 돌고 있지 않을 때만** `use` 를 실행해라. 도는 중에 갈아끼우면 그 세션이 죽는다.

---

## 5. 경로 차이

| 항목 | macOS/Linux | Windows |
|---|---|---|
| codex 홈 | `~/.codex` | `%USERPROFILE%\.codex` |
| 슬롯 저장소 | `~/.config/codex-auth` (또는 `~/.omx/auth`) | `%USERPROFILE%\.config\codex-auth` |
| 레인 | `~/.codex-lanes/<pid>` | `%USERPROFILE%\.codex-lanes\<pid>` |
| 저장소 재지정 | `CODEX_AUTH_DIR=…` | `$env:CODEX_AUTH_DIR="…"` |

`homedir()` 기준이라 경로 자체는 알아서 잡힌다 — 손으로 지정할 일은 없다.

---

## 6. 요약

| 쓰는 환경 | 슬롯 관리 | 자동 전환 | 세션 격리 | 안전 가드 |
|---|---|---|---|---|
| **WSL2** | ✅ | ✅ | ✅ | ✅ |
| Git Bash | ✅ | ✅ | ⚠️ 개발자 모드 필요 | ❌ |
| PowerShell | ✅ | ❌ 수동 | ❌ | ❌ |

가드가 없는 환경에서 `codex exec` 병렬 배치를 돌리지 마라. 그게 계정을 태우는 가장 빠른 길이다.
