---
name: codex-auth
description: "Manage multiple ChatGPT accounts for the Codex CLI by swapping ~/.codex/auth.json into named slots — add an account, switch the active one, read per-slot remaining quota and per-account token usage history, diagnose a dead slot, and rotate when Codex hits a usage limit. Needs nothing but the codex CLI and node. **The agent switches slots itself** when a delegated `codex exec` batch dies on quota. Use whenever the user mentions codex 계정 전환 / 계정 바꿔 / 계정 추가 / 쿼터 남았어? / 사용량 한도 / usage limit / rate limited on codex / 토큰 없어 / 충전했어 / 다른 계정으로 / 슬롯 / 얼마나 썼어 / 토큰 사용량, whenever a `codex exec` run exits nonzero during batch delegation, whenever the user says dscodex launched on an exhausted account (dscodex 가 계정을 안 바꾼다 / 쿼터 없는데 그냥 뜬다), or when the user types /omj:codex-auth."
argument-hint: "[list|check|use <slot>|add <slot>|quota|usage|next|preflight]"
---

# Codex 계정 관리 (auth.json 슬롯)

공식 `codex` 는 계정이 하나다 — `codex login` 은 단일 계정이고 `codex logout` 은 통째로 지운다.
이 스킬이 계정별 `auth.json` 을 **슬롯 파일**로 보관하고 `~/.codex/auth.json` 을 갈아끼운다.
외부 도구는 필요 없다 (codex CLI + node 18+ 면 된다).

```bash
S=~/.claude/skills/codex-auth/scripts/codex-auth.mjs   # 어느 프로젝트에서든 이 경로
$S list                 # 슬롯 + 현재 표시 + 이메일
$S check                # 정합성 진단 (어긋나면 exit 1)
$S use <slot>           # 전환 (write-back → 마운트)
$S add <slot>           # 새 계정 추가 (device auth)
$S sync                 # live 의 회전된 토큰을 현재 슬롯에 되돌리고, 다음 launch의 쿼터 cache를 비운다
$S quota [--json]       # 슬롯별 남은 % · 리셋 시각 (live 를 안 건드린다)
$S usage [--days N]     # 슬롯별 토큰 사용량 — 최근 N일·피크·누적 (기본 7일)
$S next                 # 남은 % 가 가장 많은 슬롯으로 전환 (안전 하한 2%, --min 으로 더 높게 조정)
$S preflight            # 세션 띄우기 직전 점검 — 소진이면 자동 전환. dscodex 가 부른다
$S remove <slot>        # 슬롯 파일만 삭제 (live 인증·ChatGPT 세션은 그대로)
```

**뭔가 이상하면 먼저 `check`.** codex 유무·자격증명 저장소·현재 슬롯↔live 일치·파일 권한·
`last_refresh` 드리프트·실행 중인 codex 를 한 번에 보고, 어긋난 항목마다 고칠 명령을 같이 준다.

슬롯은 `~/.config/codex-auth/<slot>.json` (0600, auth.json 복사본) + `slots.json` (메타데이터).
`CODEX_AUTH_DIR` 로 재정의할 수 있고, **`~/.omx/auth/` 가 이미 있으면 그 저장소를 그대로 쓴다** —
omx 를 쓰던 머신에서 슬롯을 복사해 두 벌로 만들면 낡은 쪽이 live 를 덮어 계정을 죽인다.

**전제 — `~/.codex/config.toml` 의 `cli_auth_credentials_store = "file"`.** codex 가 macOS 키체인
모드면 `auth.json` 을 갈아끼워도 통째로 무시된다. 전환이 "성공" 으로 찍히고 계정은 그대로인 게
가장 나쁜 실패라, 스크립트는 이 값이 없으면 전환을 **거부**한다. 대가로 계정 N개의 refresh token 이
평문 JSON(0600)에 모인다 — 동작 전제라 끌 수 없다.

---

## 에이전트가 직접 전환한다

`codex exec` 를 여러 개 띄워 위임하다 쿼터가 끊기는 게 가장 흔한 상황이다.
사용자에게 물어보지 말고 아래 순서대로 처리한다.

### 1. 전환을 막는 건 "codex 가 살아 있음" 이 아니다

두 가지만 막는다.

- **`codex exec` 배치가 도는 중.** 레인이 auth 를 다시 읽는 순간 account id 가 안 맞으면 그 레인은
  auth reload 를 건너뛰고 죽는다 (`Skipping auth reload due to account id mismatch`).
  **한 레인 살리려다 아홉을 죽인다.** 하나가 쿼터로 죽어도 표시만 해 두고 나머지가 끝날 때까지 기다린다.
- **토큰 회전 레이스.** 나가는 계정의 access token 만료가 30분 안이면 살아있는 codex 가 곧 refresh 를
  돌린다. 그 순간 전환이 겹치면 회전된 새 토큰이 live 에만 남았다가 덮여 사라지고, 나가는 슬롯은
  이미 소비된 토큰을 든 채 남는다 → `token_revoked`. 이게 전환을 막아야 하는 *진짜* 이유다.

`codex app-server`(MCP·플러그인 브로커)와 대화형 세션은 **막지 않는다.** Claude Code 의 codex
플러그인이 세션 내내 app-server 를 띄워 두므로, 그것까지 "실행 중" 으로 세면 전환이 **영원히** 안 된다 —
2026-08-19 에 실제로 그랬다 (전 슬롯이 0%·폐기 상태인데 `next` 가 매번 "거부: codex 가 실행 중" 으로만
끝났다. 자동 전환이 안 되는 것처럼 보인 원인이 이 가드다). 대신 무엇이 돌고 있는지 한 줄로 알린다 —
**그 프로세스들은 재시작 전까지 옛 계정을 계속 쓴다.**

감지는 `pgrep -f codex` 가 아니라 **argv 의 실행 토큰**으로 한다. 문자열 매칭은 명령줄에 "codex" 가
든 남의 셸까지 잡고, `comm` 은 codex 가 node 래퍼면 `node` 로 뜨는 데다 macOS 에서 15자에 잘린다.
서브커맨드도 "첫 비플래그 토큰" 이 아니라 알려진 키워드(`exec` / `app-server`·`mcp`·`proto`)로 본다 —
`codex --model x exec` 처럼 값 받는 플래그가 앞에 오면 그 값을 서브커맨드로 읽는다.

### 2. write-back 은 스크립트가 한다 — 하지만 왜인지는 알아야 한다

슬롯은 **스냅샷**이다. codex 가 세션 중 refresh token 을 회전시키면 live 에만 새 토큰이 남는다.
그 상태에서 옛 슬롯 복사본으로 live 를 덮으면 이미 회전된 refresh token 을 다시 제시하게 되고,
OpenAI 의 재사용 탐지가 그 계정의 토큰 패밀리를 통째로 폐기한다 → `token_revoked`, 재로그인 외 복구 불가.

`use` 는 **나가는 슬롯을 먼저 write-back** 하고, `use <현재슬롯>` 은 live 를 덮는 대신 **슬롯을 최신화**한다
(낡은 스냅샷으로 회전된 live 를 덮는 게 가장 조용한 사고 경로다). 수동으로 codex 를 오래 돌렸으면 `sync`.

### 3. 다음 슬롯은 `next` 로 고른다 — 라운드로빈 금지

`next` 는 사다리를 위에서부터 탄다. 라운드로빈으로 다음 칸을 밟으면 소진 계정을 먼저 골라
codex 기동을 N번 헛돈다.

1. **남은 %가 가장 많은 슬롯.** 확실한 신호가 있으면 그게 이긴다.
2. **동률이면 가장 오래 안 쓴 슬롯** (`lastUsedAt` 오름차순, 한 번도 안 쓴 것이 가장 위).
   최근에 쓴 것부터 밟으면 방금 소진시킨 계정을 다시 고른다 — 5시간 창은 그 계정을 마지막으로
   쓴 시점부터 흐르므로, 오래 묵은 슬롯일수록 창이 이미 돌았다.
3. **잔량이 읽히는 슬롯이 전부 소진됐으면, 조회에 실패한 슬롯을 오래된 순으로 시도한다.**
   `"모른다" 는 "못 쓴다" 가 아니다` — 예전엔 조회 실패 슬롯을 통째로 버려서, 타임아웃 한 번에
   멀쩡한 계정까지 "쓸 수 있는 슬롯이 없다" 로 덮였다. 표시는 `잔량 미상` 이고, 추측이므로
   `preflight` 는 그 결과를 캐시하지 않는다.

**폐기로 확인된 슬롯은 이 마지막 수단에 들어오지 않는다.** 그 기록은 끈적해서 (`health.state`),
`ok` 조회 하나로만 지워진다 — 조회 실패는 살아났다는 증거가 아니다.
실측 (2026-08-27): 두 sweep 이 `token_invalidated` 로 확인한 슬롯이 그 사이 조회에서 침묵하자,
3단계가 그 침묵을 "모른다" 로 읽고 골랐다. 그 계정은 뒤에 실제로 되살아났지만 (다음 sweep 에서
`ok` 80%, 기록도 자동으로 지워졌다) 고를 시점의 유일한 증거는 폐기였다 — 운을 근거로 쓰지 않는다.

쓸 수 있는 슬롯이 없으면 **이유를 둘로 나눠** 보고하고 멈춘다. 다음 행동이 완전히 다르기 때문이다.

- **쿼터 소진** → 리셋 시각을 알리고 기다린다. 사람이 할 수 있는 게 없다.
- **인증 폐기** → 자동 순환으로 못 살린다. `add <같은-슬롯명>` 이 필요한데 기기 인증 코드는 사람만 넣는다.
  이때만 사용자를 부른다.

이 둘을 한 줄로 뭉치면 에이전트가 무한히 재시도하거나 살릴 수 있는 계정을 두고 그냥 멈춘다.

### 4. 죽은 작업을 **다시 돌리기 전에 산출물부터 본다**

가장 비싼 실수가 여기 있다. `codex exec` 는 **작업을 다 끝내고 마지막 요약을 쓰다가** 쿼터로 죽는 일이 잦다.
래퍼는 `--output-last-message` 파일이 비었으니 `{"status":"error"}` 를 뱉지만 **파일 변경은 이미 디스크에 있다.**

실측: 레인 7개가 동시에 exit 1 이었는데 감사 문서 7개와 데이터 변경이 전부 남아 있었고 typecheck 도 0이었다.
그대로 재실행했으면 새 쿼터를 헛으로 태웠다. 판단은 이 순서로 — ① 산출물이 생겼나 (mtime·줄 수·기대 파일)
② 빌드가 서나 (typecheck·린트) ③ 화면·테스트로 기능이 들어왔나. 셋 다 통과면 **요약 JSON 만 유실된 것**이다.

### 5. 쿼터 소진은 직접 안 보인다

`codex exec` 를 래핑해 stdout 만 파싱하는 스크립트는 stderr 를 버려 `.err` 가 0바이트로 남는다.
쿼터라는 증거가 아무 데도 없다. 대신 이 신호로 읽는다:

- exit code ≠ 0 **인데** `.err` 는 비어 있다
- **여러 레인이 같은 순간에** 죽는다 ← 쿼터의 결정적 지문. 코드 문제라면 하나만 죽는다
- 직전까지 정상 진행 중이었다

배치를 돌릴 땐 래퍼가 stderr 를 남기게 고쳐 두는 게 낫다: `codex exec ... 2> "$ERR"` 로 받고
실패 시 `grep -qiE "usage limit|quota|429"` 로 분류한다.

### 배치 레인

```bash
# 한 레인 — 쿼터로 죽으면 표시만 남기고 재시도하지 않는다
bash run-codex.sh <project> "$(cat /tmp/codex-briefs/$1.txt)" > /tmp/codex-out/$1.json 2> /tmp/codex-out/$1.err
grep -q '"status": *"done"' /tmp/codex-out/$1.json || echo "$1" >> /tmp/codex-out/QUOTA_FAILED
```

**레인 안에서 자동 재시도·자동 전환을 넣지 마라.** 다른 레인이 도는 중에 슬롯이 바뀌면 전부 죽는다.
전환은 배치 바깥에서, 전원 종료 뒤에 `$S next`.
`next`·`preflight` 는 **잔량 2% 이상**인 슬롯만 쓸 수 있는 슬롯으로 센다 (`--min` 으로 더 높게 조정 가능).
실제 5시간 한도 오류가 `usedPercent: 99`(표시 잔량 1%)에서 발생하므로, `--min 0`이나 `--min 1`도 이 안전 하한을 낮추지 못한다.

(omx 의 `--hotswap` 처럼 **세션을 resume 하며 도중에 갈아타는 기능은 없다.** 자동 전환은
**띄우기 직전** 한 번뿐이다 — 아래 `preflight`.)

---

## 레인 — 세션마다 계정을 격리한다 (2026-08-28)

세션이 전부 `~/.codex/auth.json` 하나를 공유하면 계정 하나가 소진될 때 **열어둔 세션이 전부 같이
만료된다** (실측: 슬롯 8개가 살아 있는데 세션 5개가 한 계정을 써서 동시에 죽었다).

**레인** = `~/.codex` 의 모든 항목을 심링크하고 **`auth.json` 만 실파일**로 둔 홈.
`config.toml`·hooks·MCP·`sessions` 는 원본을 그대로 쓰고 계정만 갈린다. `dscodex` 가 세션마다 하나 만든다.

```bash
$S lane new --pid $$ [slot]   # 레인을 만들고 경로를 한 줄로 출력 (CODEX_HOME 으로 쓴다)
$S lane list                  # 어느 슬롯을 누가 잡고 있나
$S lane release --pid $$      # 반납 (dscodex 가 종료 시 자동)
```

- **슬롯은 배타 대여다.** 두 레인이 같은 계정을 쓰면 각자 refresh token 을 회전시키고, 재사용 탐지가
  그 계정을 통째로 폐기한다. `lane.json` 의 pid 가 살아 있는 동안만 대여로 세므로 죽은 락을 손으로
  지울 일이 없다. `next`·`preflight` 는 대여 중인 슬롯을 후보에서 뺀다.
- **"현재 슬롯" 은 레인 안에서 그 레인 것이다.** 전역 `slots.json` 을 쓰면 레인 A 의 전환이 B 의 기록을
  덮어 B 가 엉뚱한 슬롯에 write-back 한다.
- 레인 안에서 이 스크립트를 부르려면 `CODEX_HOME=<레인>` 만 주면 된다 — `LIVE`/`CONFIG` 가 거기를 본다.
- 레인 생성이 실패하면 공유 홈으로 그냥 띄운다. **레인도 launch 를 막지 않는다.**
- 같은 이유로 런처는 `set -u` 를 쓰지 않는다 — unbound 하나로 codex 를 못 띄우는 게 변수 오타보다 나쁘다.
  대신 분기에서 쓰는 변수를 상단에서 전부 초기화한다. 이상하면 `DSCODEX_DEBUG=1 codex` 로 띄우고
  `$TMPDIR/dscodex-debug.log` 를 보면 실행 순서가 전부 남는다.

## `dscodex` — 띄우기 직전 자동 전환 (`preflight`)

`dscodex` 는 `skills/codex-auth/scripts/dscodex.sh` 를 부르고, 그 스크립트가
**codex 를 띄우기 전에 `preflight`, 끝난 뒤에 `sync --quiet`으로 토큰을 되돌리고 쿼터 cache를 지운다.**
(`~/.zshrc` 의 `dscodex()` 는 이 파일로 넘기는 3줄뿐이다 — 로직은 레포에서 git 으로 추적한다.)

터미널에서 대화형 Codex가 `You've hit your usage limit`·rate-limit·429 한도 신호와 함께 종료하면,
`dscodex`는 그 메시지를 PTY transcript로 확인한다. API 반영이 늦어도 **오류를 낸 현재 슬롯만** 이번
선택에서 제외하고, 실제로 다른 슬롯이 마운트된 경우에만 새 Codex 세션을 한 번 시작한다. transcript는
판정 뒤 즉시 삭제한다. 일반 오류·인증 오류·Ctrl-C와 `codex exec` 배치는 전환하거나 재시작하지 않는다.
이전 대화는 새 계정에서 자동 `resume`되지 않는다.

```
preflight: raymondhardy8225 100% 남음                    ← 평소: 조회 1회 (약 2초)
preflight: raymondhardy8225 100% (3분 전 확인)            ← TTL(10분) 안: 조회 생략 (60ms)
preflight: donnie7 0% — 남은 슬롯을 찾는다 (7개 조회)
preflight: 전환: donnie7 (0%) → raymondhardy8225 (100%)   ← 소진일 때만 전 슬롯 sweep
```

**launch 마다 죽은 슬롯을 먼저 알린다.** 인증 폐기는 로테이션으로 안 살아나고 사람이 기기 인증을
해야만 돌아온다 — 그게 launch 때 안 보이면 "쿼터가 없네" 로 오해된 채 몇 주씩 방치된다.
전수 조회를 launch 앞에 붙일 수는 없으므로 (슬롯 11개 ≈ 13초), sweep 이 돌 때 `health.state` 에
적어 두고 launch 는 그걸 읽는다 — **네트워크를 쓰지 않는다.**

```
preflight: 인증이 폐기된 슬롯 4개 (2026-08-27 12:31 확인) — 로테이션으로는 못 살린다. 기기 인증은 사람만 할 수 있다:
  node ~/.claude/skills/codex-auth/scripts/codex-auth.mjs add cooper.larkin --force   # cooper.larkin@qlking.com
  ...
  → 화면에 뜨는 URL 과 코드를 브라우저에서 열고 **그 슬롯의 계정으로** 로그인하면 된다.
     다른 계정이 로그인된 브라우저면 그 계정이 중복 등록된다 — 시크릿 창을 쓰거나 먼저 로그아웃하라.
  계정별 잔량 전체: node ~/.claude/skills/codex-auth/scripts/codex-auth.mjs quota
```

명령은 서브커맨드만이 아니라 **그대로 붙여넣을 수 있는 전체 줄**로 찍는다 (`add <slot>` 만 찍으면
경로를 매번 되찾아야 하고, 이미 있는 슬롯이라 `--force` 없이는 거부된다).
배너에서 빠지는 조건은 셋이다 — 재로그인 성공 (`add`), 슬롯 삭제 (`remove`), 다음 sweep 의 `ok`.

지키는 규칙 세 가지. 셋 다 사고가 나서 생겼다.

1. **launch 를 막지 않는다.** 무슨 일이 있어도 `exit 0`. 계정을 골라 주는 편의가 codex 를 못 쓰게
   만드는 것보다 나쁘다. 잠금 충돌·조회 실패·저장소 설정 오류는 한 줄 경고 후 그대로 띄운다.
2. **인증 오류에는 로테이션하지 않는다.** 옛 omx hotswap 이 인증 실패를 "이 계정 못 쓴다" 로 읽고
   슬롯을 줄줄이 밟아 로그인 화면조차 못 보게 만들었다. 도는 건 **쿼터일 때뿐**이다
   (위 「인증 오류에 계정을 돌리지 마라」 와 같은 규칙).
3. **한 세션 안에서는 조회 1회.** 전 슬롯 sweep(실측 7개 13초)은 현재 슬롯이 실제로 소진됐을 때만.
   결과는 `preflight.state` 에 캐시되지만, 세션 종료의 `sync --quiet`가 이를 지운다. 세션 동안 5시간
   쿼터가 소진될 수 있으므로 다음 `dscodex` launch는 TTL 안이어도 현재 값을 다시 읽는다.

그리고 **`codex exec` 배치가 돌면 전환하지 않는다** — 한 레인 살리려다 아홉을 죽인다.
비어 있는 슬롯을 알려만 주고 그대로 띄운다.

```bash
CODEX_AUTH_NO_PREFLIGHT=1 dscodex     # 점검 없이 바로
$S preflight --force                  # 캐시 무시하고 다시 조회
$S preflight --min 3 --ttl 60         # 하한 3%, 캐시 60초
```

`login`·`logout`·`app-server`·`--version` 같은 서브커맨드에는 preflight 를 붙이지 않는다
(로그인 도중에 슬롯을 갈아끼우면 사용자가 방금 넣은 계정이 아닌 곳에 로그인한다).

**한도 판정은 화면이 아니라 API 로 한다 (2026-08-28).** 런처는 codex 를 감싸지 않는다 — TUI 는
사용자 터미널에 직접 붙는다. 비정상 종료(`rc`≠0) 뒤에 `preflight --force` 를 한 번 돌리고,
**계정이 실제로 갈렸으면** 그게 곧 한도로 죽었다는 증거다. 잔량이 남아 있으면 preflight 가 전환하지
않으므로 재시작도 없다 — 오탐이 원천적으로 불가능하다.
**인터럽트(`rc` 130·143)는 제외한다** — codex 의 정석 종료는 `Ctrl+C` 두 번이고, 사용자가 그만두겠다고
말한 것을 재시작 근거로 쓰지 않는다. 정상 종료(`rc` 0)는 애초에 판정에 들어가지 않는다.
재시작 직전에는 3초를 세고 아무 키나 누르면 그만둔다 (`DSCODEX_CONFIRM_SECS=0` 으로 끈다).

⛔ **런처 전체는 `main()` 안에 있고 `main "$@"; exit $?` 로 끝난다. 새 줄은 반드시 그 안에 넣어라.**
bash 는 실행 중 스크립트를 파일 오프셋으로 이어 읽으므로, 감싸지 않으면 세션이 떠 있는 동안 이 파일을
고쳤을 때 **세션을 닫는 순간 엉뚱한 바이트에서 파싱해** 존재하지 않는 줄의 에러가 쏟아진다.

**한도로 죽으면 그 대화를 이어서 재개한다 (2026-08-28).** `codex resume <SESSION_ID>` 를 쓴다.
세션 id 는 `~/.codex/sessions/…/rollout-*.jsonl` 첫 줄 `session_meta` 에서 얻고, **실행 직전 마커 파일보다
새 것 + 같은 `cwd`** 로 자기 세션을 특정한다. 못 찾으면 예전처럼 빈 세션을 띄운다.

**`codex` 를 치면 바로 이 런처로 간다** — `~/.zshrc` 의 `codex()` 가 감싼다. 원본이 필요하면
`command codex` 또는 `CODEX_PLAIN=1 codex`. `login`·`--version` 같은 비세션 서브커맨드에는
bypass 플래그를 안 붙이고 원본 그대로 넘긴다.

**한계**: 이미 떠 있는 세션을 **도중에** 계정만 바꿔 계속할 수는 없다. codex 는 시작할 때 인증을 읽고,
살아 있는 프로세스의 auth 를 갈아끼우면 그 프로세스가 죽는다 (옛 omx hotswap 이 그러다 슬롯을 태웠다).
한도로 **종료된 뒤**에 갈아끼우고 resume 하는 것이 지금 할 수 있는 최선이다.

---

## 쿼터 읽기

```
SLOT                      남음  리셋                  창     플랜     크레딧
donnie7                 100%  8. 20. 오후 03:36     5h    plus   none
ruin.mvbm6               97%  8. 20. 오후 01:38     5h    plus   none
raymondhardy8225          0%  8. 21. 오전 09:52     7d    plus   none
rupy1014                인증 폐기 — 재로그인 필요 (token_invalidated)
```

- codex app-server 의 `account/rateLimits/read` 를 부른다. **모델 쿼터를 소모하지 않는다.**
- **임시 `CODEX_HOME` 에 슬롯을 복사해 묻는다 — live `auth.json` 을 건드리지 않는다.** 그래서 배치가
  도는 중에도 안전하다 (검증: 임시 홈 값이 마운트해서 읽은 값과 같았다). 예외는 하나 — 지금 마운트된
  슬롯의 토큰 갱신이 임박했고 codex 가 돌고 있으면 그 슬롯만 건너뛴다. 같은 refresh token 을 두 곳에서
  회전시키면 그게 곧 `token_revoked` 다.
- `quota`가 현재 슬롯의 실제 값을 받으면 preflight cache도 그 값으로 갱신하고, 2% 미만·조회 실패면 cache를
  지운다. 조회 직후 `dscodex`가 이전 양수 값을 믿고 시작하지 않게 하기 위해서다.
- **`100%` + 리셋이 "지금+창길이" 는 값 없음이 아니라 "이번 창에서 아직 안 썼다" 는 실제 응답이다.**
  실측으로 확인했다 — 그 상태의 슬롯으로 `codex exec` 가 그대로 돈다. 반대로 **리셋이 과거 시각에
  앵커돼 있으면** 그 계정이 실제로 그 창에서 썼다는 뜻이다.
- **남은 %는 5시간·장기 창 중 더 빡빡한 쪽이다.** 계정에 따라 5시간 창이 primary 로 오고 주간이
  secondary 로 온다. 어느 이름도 가정하지 않고 둘을 모두 보존한 뒤, 더 낮은 잔량만 `next`·`preflight`의
  선택 기준으로 쓴다. 5시간 창이 0%이거나 provider가 이미 차단할 수 있는 1%를 보고하면, 주간 잔량이
  남아 있어도 다른 슬롯으로 전환한다.
  `창` 칼럼은 지금 발목을 잡고 있는 창이고, `quota --json`의 `windows`·`bindingWindow`로 두 창과 선택 근거를
  함께 확인할 수 있다.
- 실패는 **이유별로 다르게 찍힌다** — `인증 폐기 (token_invalidated)` 는 사람이 `add` 로 재로그인해야
  하고, `조회 실패 (네트워크/…)` 는 그냥 재시도다. 원문은 `--json` 의 `detail` 에 그대로 남는다.
  (예전에는 둘 다 "조회 실패 (인증 폐기/네트워크)" 한 줄이라 구분이 불가능했다.)
- 반대로 **숫자가 나왔다는 건 인증이 살아있다는 증거** 다 — rate limit 을 읽으려면 토큰이 유효해야 한다.
  `check` 의 슬롯별 `ok` 는 **파일이 멀쩡하다**는 뜻일 뿐, 인증 생사와 무관하다.
- `--json` 의 `windowMins` 가 `10080` 이면 **주간** 창이라 리셋까지 며칠 걸린다. 전 슬롯이 0% + 주간이면
  로테이션으로는 못 뚫는다 — 리셋 시각을 알리고 멈춘다.
- **슬롯의 `access_token` 만료(JWT `exp`)를 살아있음의 근거로 쓰지 마라.** refresh token 이 폐기돼도
  이미 발급된 access token 의 `exp` 는 미래로 남는다. 로컬 `exp` 검사는 "만료됐다" 판정에만 쓴다.

## 사용량 읽기 (`usage`)

`quota` 가 "지금 얼마 남았나" 라면 `usage` 는 **"그동안 얼마나 썼나"** 다. codex app-server 의
`account/usage/read` 를 부른다 — 쿼터 조회와 같은 비용(인증만 필요, **모델 쿼터 안 씀**),
같은 안전 절차(임시 `CODEX_HOME`, live 를 안 건드림)다.

```
SLOT                      최근7일   일수  마지막               피크 (일자)              누적
jaden.kassulke20         601.4M     4  2026-08-14    221.3M (2026-08-14)  874.2M
donnie7                 인증 폐기 — 재로그인 필요 (token_invalidated)
```

- 응답은 **계정 단위**다: 일자별 토큰 버킷(쓴 날만 sparse), 누적, 피크 일, 최장 턴, 연속일.
  `--json` 에 `buckets` 원문이 그대로 들어간다.
- **가장 쓸모 있는 용법은 "내가 안 쓴 날에 토큰이 찍힌 슬롯" 찾기다.** 그 계정은 다른 머신이나
  다른 사람이 같이 쓰고 있다는 뜻이고, 그게 슬롯이 죽는 경로다 (위 auth.json 유출 절 참조).
- 쿼터 잔량과 직접 이어지진 않는다. 잔량은 창(5h·주간) 기준 %이고 여기는 절대 토큰 수다 —
  **다음에 쓸 슬롯을 고르는 건 여전히 `next`(=`quota`) 다.** `usage` 는 사후 분석용이다.

## 슬롯 이름은 이메일 앞부분으로

이름이 어느 ChatGPT 계정인지 알려주는 유일한 단서다 — `rupy1014`, `donnie7` 처럼 로컬파트를 쓴다
(`list` 가 `id_token` 을 까서 이메일을 같이 보여준다. 네트워크·쿼터 안 씀).

규칙은 1~64자, 영문·숫자·`.`·`_`·`-`, 첫 글자는 영문 또는 숫자. **이름 검사는 로그인 전에 한다** —
이메일 전체(`@` 포함)를 슬롯명으로 주는 게 가장 흔한 실패고, 로그인 뒤에 걸리면 받아온 토큰을 버린다.

## Windows

**WSL2 를 써라.** 네이티브 Windows 에서는 `ps` 가 없어 **전환 가드가 조용히 꺼지고**(도는 codex 를
감지 못해 `codex exec` 배치 중에도 전환한다 → 레인이 줄줄이 죽거나 토큰 회전 레이스로 계정을 잃는다),
심링크 권한이 없으면 레인(세션 격리)도 안 만들어진다. `check` 가 그 상태를 한 줄로 말해 준다.

환경별로 무엇이 되고 안 되는지, WSL2·Git Bash·PowerShell 각각의 절차와 경로 차이는 **`WINDOWS.md`**.

## 왜 이렇게 되어 있나 (결정 기록)

규칙 하나하나가 실제 사고에서 나왔다. 되돌리기 전에 `HISTORY.md` 를 읽어라 — 무엇을 하는지는 이 문서에,
**왜 그렇게 했는지**는 거기에 있다. 새 결정은 그 저널 맨 위에 날짜 키로 덧붙인다 (과거 항목 편집 금지).

## 계정 추가

`add` 는 **새로 기기 인증**을 한다. 이미 `codex login` 으로 로그인해 둔 계정을 슬롯으로 편입하려면
`adopt` 를 쓴다 — live 를 건드리지 않고 스냅샷만 뜬다.

```bash
$S adopt              # live 계정을 이메일 앞부분 이름으로 편입
$S adopt gracie24     # 이름을 직접 지정
```

```bash
$S add <slot>
```

임시 `CODEX_HOME` 에서 `codex login --device-auth` 를 돌리고 결과 `auth.json` 만 슬롯으로 복사한 뒤
임시 디렉토리를 지운다. **로그인하는 동안 지금 쓰는 계정이 건드려지지 않는다.**

- **`--device-auth` 를 쓴다.** 브라우저 콜백(포트 1455) 방식은 이전 로그인이 남긴 `localhost:1455` 탭이
  재요청되면서 `State mismatch` 가 난다. 계정을 연달아 추가할 때 거의 반드시 발생한다.
- 브라우저에 이전 계정이 남아 있으면 같은 계정이 중복 등록된다. 시크릿 창을 쓰거나 chatgpt.com 에서
  로그아웃하고 진행한다 (스크립트가 `account_id` 중복을 감지해 알려준다).
- 추가됐는지는 사용자 말이 아니라 `list` 와 슬롯 파일의 존재·mtime 으로 확인한다.

## ⛔ 인증 오류에 **계정을 돌리지 마라** (2026-08-19 추가)

`codex exec` 가 인증 오류로 죽었을 때 **다른 슬롯으로 전환하는 것은 거의 항상 오답이다.**
전환은 **쿼터 소진**에만 쓴다. 문구로 가른다 — 행동이 정반대다.

| 에러 문구 | 정체 | 할 일 |
|---|---|---|
| `You've hit your usage limit` · `try again at …` | 쿼터 | `quota` 로 남은 슬롯 확인 → 있으면 `use`, 없으면 **중단** |
| `refresh token was revoked` | 인증 | 아래 ①②③ |
| `logged out or signed in to another account` | 인증 | 아래 ①②③ |

### ① 먼저 `list` / `sync` 가 찍는 지시를 그대로 실행한다

```
donnie7: live 가 슬롯보다 낡았다 (live 2026-08-13 < slot 2026-08-19)
         'use donnie7' 로 live 를 슬롯에 맞춰라
```

**이건 참고사항이 아니라 처방이다.** 사용자가 방금 재인증했는데 live `auth.json` 만 옛 토큰인
상황이 흔하다(재인증이 슬롯을 갱신했고 live 는 그대로). `use <그 슬롯>` 한 번이면 끝난다.

### ② 그래도 안 살면 **거기서 멈추고 사용자에게 기기 인증을 요청한다**

`add <같은-슬롯명>` 이 필요한데 **기기 인증 코드는 사람만 넣는다.** 다른 슬롯을 시험 삼아
돌리지 마라 — 그 슬롯들도 같은 이유(같은 머신·같은 재인증 시점)로 죽어 있을 확률이 높고,
돌릴 때마다 live 가 갈려서 나중에 무엇이 원인이었는지 못 짚는다.

### ③ 실측 사고 (이 절이 생긴 이유)

2026-08-19: 사용자가 그날 아침 전 계정을 재인증했는데 live 만 6일 전 토큰이었다.
위임이 `refresh token was revoked` 로 죽자 **그걸 슬롯 사망으로 오진하고 두 계정을 갈아끼웠다.**
셋 다 인증 오류를 냈다. 진짜 원인은 둘이었고 **둘 다 명령 한 번이면 보였다** —
`sync` 가 이미 ①의 처방을 출력하고 있었고, `quota` 는 전 슬롯 `0%` 를 보여 줬다
(애초에 위임을 하지 말았어야 했다).

> **교훈**: 위임 전에 `quota`, 실패하면 **문구부터 읽는다.** 계정을 돌리는 건 마지막이 아니라
> **아예 목록에 없는** 선택지다(쿼터 소진 제외).

## 슬롯이 죽었을 때 (`token_revoked`)

증상: `Your access token could not be refreshed because your refresh token was revoked`, 또는
`401 ... "code": "token_revoked"`. 원인은 위 §2 의 스냅샷 경로다. **죽는 건 항상 직전까지 live 였던 슬롯이다.**

```bash
$S add <같은-슬롯명>    # 덮어쓴다. 기기 인증은 사람만 할 수 있다
```

진단 — `last_refresh` 는 `id_token` 의 `iat` 과 같은 시각이어야 한다. 여기가 미래로 밀려 있으면 codex 가
"방금 갱신했다"고 믿고 영영 갱신하지 않아, access token 이 만료되는 순간 슬롯이 죽는다. `check` 가
초 단위 드리프트로 잡는다 (`last_refresh` 는 마이크로초, `iat` 은 초라 문자열 비교하면 안 된다).

`⚠ MCP client for codex_apps failed ... token_revoked` 도 같은 원인이다 — 커넥터가 같은 계정 토큰을 쓴다.

## auth.json 을 다른 데로 복사하지 마라 (슬롯이 무더기로 죽는 유일한 경로)

`~/.codex/auth.json` 을 다른 머신에 rsync·Dropbox·dotfiles 로 흘려 두고 저쪽에서도 codex 를 돌리면,
저쪽이 refresh token 을 회전시키는 순간 이쪽 사본이 죽는다 (반대도 같다). 스킬이 write-back 을 아무리
잘 해도 **바깥에서 도는 복사기는 못 이긴다.**

실측 (2026-08-19): `*/2 * * * * rsync ~/.codex/auth.json <remote>:.codex/` 가 걸린 머신에서
슬롯 6개 중 5개가 `token_invalidated` 였다. `check` 가 crontab 과 LaunchAgents 를 훑어 이걸 잡는다:

```
  auth.json 유출: 1건 — 이 머신 밖으로 live 자격증명이 복사되고 있다
    crontab: */2 * * * * /usr/bin/rsync -a ~/.codex/auth.json remote:.codex/
```

두 머신에서 같은 ChatGPT 계정을 쓰고 싶으면 파일을 복사하지 말고 **슬롯을 나눠 갖는다** —
머신마다 다른 계정을 마운트하거나, 정말 같은 계정을 써야 하면 한쪽에서만 codex 를 돌린다.

## 하지 않을 것

- **`codex exec` 배치가 도는 중의 전환.** 스크립트가 막는다 (`--force` 는 그 레인을 죽일 각오가 있을 때만).
  app-server·대화형 세션은 막지 않지만, 그것들은 재시작 전까지 옛 계정을 계속 쓴다는 걸 알고 써라.
- **`codex logout` 을 제안하지 않는다.** 슬롯이 아니라 현재 `auth.json` 만 날아간다. 계정을 바꾸려면 `use`.
- **비밀번호를 묻지 않는다.** 받는 건 OAuth 토큰뿐이고 `add` 로만 들어온다. 슬롯은 `auth.json` 복사본이라
  다른 머신으로 파일 단위 **이전**은 가능하다 — 다만 **복사해 두고 양쪽에서 쓰면 안 된다** (위 유출 절 참조).
- 쿼터 확장을 위한 계정 로테이션은 OpenAI ToS 판단이 걸린다. 사용자가 요청한 범위에서 동작시키되
  우회를 대신 설계하지 않는다.

## 설치 (배포)

omj 를 설치했으면 **셸 진입점까지 자동으로 깔린다** — `install.sh` 의 `wire_codex_shell` 이
`~/.zshrc`(bash 면 `~/.bashrc`)에 `# omj:begin codex-auth` 마커 블록을 idempotent 하게 넣는다.
`--mode minimal` 이면 생략되고, `--uninstall` 이 그 블록만 도로 걷어낸다(사용자 정의는 안 건드린다).

```bash
./install.sh                 # 스킬 + 셸 진입점(codex → 런처)
exec $SHELL -l               # 새 셸부터 적용
codex-auth.mjs check
```

스킬만 손으로 옮길 때:

```bash
cp -R codex-auth ~/.claude/skills/          # 스킬 디렉토리 통째로
chmod +x ~/.claude/skills/codex-auth/scripts/codex-auth.mjs
printf 'cli_auth_credentials_store = "file"\n' >> ~/.codex/config.toml   # 이미 있으면 생략
~/.claude/skills/codex-auth/scripts/codex-auth.mjs check
bash ~/.claude/skills/codex-auth/scripts/selftest.sh    # 진짜 슬롯을 안 건드린다
```

셸 진입점을 직접 넣으려면 이 블록을 rc 파일 끝에 붙인다 (설치본과 같은 내용):

```bash
# omj:begin codex-auth
codex() {
	local launcher="$HOME/.claude/skills/codex-auth/scripts/dscodex.sh"
	if [[ -n "${CODEX_PLAIN:-}" || ! -x "$launcher" ]]; then
		command codex "$@"
	else
		"$launcher" "$@"
	fi
}
dscodex() { codex "$@"; }
# omj:end codex-auth
```

**로직은 셸에 두지 않는다.** rc 에는 런처를 부르는 껍데기만 있고 본체는
`scripts/dscodex.sh` 다 — 그래야 런처를 고칠 때 사용자 설정을 다시 만지지 않는다.

| 쓰는 법 | 결과 |
|---|---|
| `codex` | 레인 격리 + 계정 자동 전환 + 한도 시 대화 이어서 재개 |
| `dscodex` | 위와 같다 (예전 이름) |
| `command codex` · `CODEX_PLAIN=1 codex` | 원본 codex 그대로 |
| `CODEX_AUTH_NO_PREFLIGHT=1 codex` | 계정 점검 없이 바로 |
| `DSCODEX_DEBUG=1 codex` | `$TMPDIR/dscodex-debug.log` 에 실행 추적 |

`selftest.sh` 는 가짜 `CODEX_HOME`·`CODEX_AUTH_DIR` 샌드박스에서 전환·write-back·락·입력 검증을
돌린다. 토큰 회전 상황을 합성해 **나가는 슬롯이 실제로 갱신되는지**까지 본다 — 스크립트를 고쳤으면
이걸 먼저 돌려라. 전환 가드는 `CODEX_AUTH_PS_FIXTURE` 로 `ps` 출력을 주입해 검증한다
(앰비언트 codex 유무에 따라 테스트가 갈리면 정작 회귀가 났을 때 SKIP 으로 지나간다).
`quota`·`usage` 의 실제 조회는 네트워크와 살아있는 계정이 필요해 샌드박스에서 안 돈다 —
인자 검증까지만 걸고, 조회 자체는 실환경에서 확인한다.

요구사항은 `codex` CLI 와 node 18+ 뿐이다 (jq·외부 래퍼 없음). 이미 `codex login` 으로 쓰던 계정이
있으면 `add` 로 새로 받을 필요 없이 첫 슬롯으로 등록할 수 있다 — `cp ~/.codex/auth.json
~/.config/codex-auth/<slot>.json` 후 `$S use <slot>`.

## 백업

```bash
cp -p ~/.codex/auth.json ~/.codex/auth.json.bak.$(date +%Y%m%d_%H%M%S)
```

슬롯 자체가 `auth.json` 백업이므로, live 가 깨지면 `use <slot>` 으로 되돌리는 게 가장 빠르다.
