#!/usr/bin/env bash
# dscodex — codex 를 bypass 모드로 띄우되, **세션마다 계정을 격리**하고 한도로 죽으면
# 다른 계정으로 갈아끼워 **그 대화를 이어서** 다시 띄운다.
#
# 이 파일이 생긴 이유 (2026-08-20): `dscodex` 가 `codex --dangerously-bypass-...` 한 줄이라
# 쿼터 0인 슬롯이 마운트돼 있어도 그대로 떴다. 그래서 preflight 를 앞에 붙였다.
#
# 레인이 생긴 이유 (2026-08-28): 세션이 전부 ~/.codex/auth.json 하나를 공유해서, 계정 하나가
# 소진되면 열어둔 세션이 **전부 같이** 만료됐다 (슬롯이 8개 살아 있는데도). 레인은 ~/.codex 를
# 통째로 심링크하고 auth.json 만 실파일로 둔 홈이다 — hooks·MCP·config·sessions 는 원본을
# 그대로 쓰고 계정만 갈린다. 세션 A 의 전환이 세션 B 를 죽이지 않는다.
#
# 규칙: **preflight 도 레인도 launch 를 막지 않는다.** 무슨 일이 있어도 codex 는 뜬다.
#   끄려면: CODEX_AUTH_NO_PREFLIGHT=1 dscodex
# -e 는 쓰지 않는다 — 보조 단계가 실패해도 codex 는 떠야 한다.
# -u 도 쓰지 않는다: 이 스크립트의 실패 모드는 "변수 오타" 가 아니라 "codex 를 못 띄움" 이고,
# unbound 하나로 런처가 통째로 죽으면 그게 훨씬 나쁘다. 대신 쓰는 변수를 전부 미리 초기화한다.
set -o pipefail
DSCODEX_DEBUG="${DSCODEX_DEBUG:-}"
[ -n "$DSCODEX_DEBUG" ] && { exec 2>>"${TMPDIR:-/tmp}/dscodex-debug.log"; set -x; echo "=== $(date) $* ==="; }

# 아래에서 참조하는 것들. 분기 어디로 가든 unset 이 되지 않게 한 자리에서 정한다.
rc=0
lane=""
marker=""
quota_error=0
sid=""


# ⛔ 이 아래는 전부 main() 안이다. **함수로 감싸는 이유가 있다.**
# bash 는 실행 중인 스크립트를 통째로 읽지 않고 파일 오프셋을 유지하며 이어 읽는다. 그래서
# 세션이 떠 있는 동안(= 이 스크립트가 `codex` 에서 블록된 동안) 파일이 수정되면, 세션을 닫고
# 나머지를 이어 읽을 때 **엉뚱한 바이트 위치**에서 파싱한다 — 존재하지 않는 줄 번호의 syntax
# error 가 종료할 때마다 쏟아진다 (실측 2026-08-28: 이 파일을 고치는 동안 열려 있던 세션 6개가
# 닫을 때마다 그랬다. 파일 자체는 bash·sh·zsh 어디서도 멀쩡히 파싱됐기에 재현이 안 됐다).
# 함수 정의는 한 번에 읽혀 메모리에 올라가므로, main() 안에 있으면 실행 중 수정에 영향받지 않는다.
# 새 줄을 추가할 때는 반드시 main() 안에 넣어라.
main() {
	HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
	AUTH="$HERE/codex-auth.mjs"
	BYPASS="--dangerously-bypass-approvals-and-sandbox"
	# 레인으로 바꾸기 **전** 홈. rollout 은 레인이 아니라 여기 쌓인다 (레인의 sessions 는 심링크).
	ORIG_HOME="${CODEX_HOME:-$HOME/.codex}"

	# 세션이 아닌 서브커맨드에는 손대지 않는다. login/logout 은 인증을 바꾸는 중이라 그 앞에서
	# 슬롯을 갈아끼우면 사용자가 방금 넣은 계정이 아닌 곳에 로그인한다.
	skip=0
	retry_after_quota=1
	case "${1:-}" in
		login|logout|app-server|mcp|mcp-server|proto|completion|--help|-h|--version|-V) skip=1 ;;
	esac
	# exec 배치는 여러 레인이 같은 auth 를 읽을 수 있다. 실패한 레인을 여기서 재시작하거나
	# 전환하면 나머지를 죽일 수 있으므로, 대화형 launch 만 단일 재시작한다.
	for arg in "$@"; do [ "$arg" = "exec" ] && retry_after_quota=0; done
	[ -n "${CODEX_AUTH_NO_PREFLIGHT:-}" ] && skip=1
	command -v node >/dev/null 2>&1 || skip=1
	[ -f "$AUTH" ] || skip=1

	# ── 레인 확보 ─────────────────────────────────────────────────────────
	# 실패하면 레인 없이 그대로 간다 (예전 동작). 계정을 갈라 주는 편의가 codex 를 못 띄우게
	# 만드는 것보다 나쁘다.
	if [ "$skip" -eq 0 ]; then
		# CODEX_SLOT 으로 계정을 직접 고를 수 있다. 대여 중이어도 만든다 — 사람의 선택이 우선이고,
	# 위험(같은 계정을 두 세션이 회전)은 preflight --pin 이 경고로 알린다.
	if [ -n "${CODEX_SLOT:-}" ]; then
		# 사람이 고른 경우엔 실패 이유를 감추지 않는다 (없는 슬롯 이름이 가장 흔한 실수다).
		lane="$(node "$AUTH" lane new --pid "$$" "$CODEX_SLOT")" || lane=""
	else
		lane="$(node "$AUTH" lane new --pid "$$" 2>/dev/null)" || lane=""
	fi
		if [ -n "$lane" ] && [ -d "$lane" ]; then
			export CODEX_HOME="$lane"
			trap 'node "$AUTH" sync --quiet >/dev/null 2>&1; node "$AUTH" lane release --pid '"$$"' >/dev/null 2>&1' EXIT
		else
			lane=""
			echo "dscodex: 레인을 만들지 못했다 — 공유 홈으로 띄운다 (다른 세션과 계정을 같이 쓴다)" >&2
		fi
	fi

	# preflight 에 codex 인자를 넘기지 않는다 — 서로 다른 플래그 문법이라 조용히 오해석된다.
	# 고른 계정이 있으면 --pin: 잔량만 알려 주고 갈아끼우지 않는다.
	if [ "$skip" -eq 0 ]; then node "$AUTH" preflight ${CODEX_SLOT:+--pin} || true; fi

	# 이 실행이 만든 세션만 골라내기 위한 시각 기준점. rollout 파일은 원본 ~/.codex/sessions 에
	# 쌓이므로 (레인의 sessions 는 심링크다) 거기서 marker 보다 새 것 + 같은 cwd 를 찾는다.
	if [ "$retry_after_quota" -eq 1 ]; then marker="$(mktemp "${TMPDIR:-/tmp}/dscodex-mark.XXXXXX")" || marker=""; fi

	find_session_id() {
		[ -n "$marker" ] || return 0
		find "$ORIG_HOME/sessions" -name 'rollout-*.jsonl' -newer "$marker" -print0 2>/dev/null |
			node -e '
	const fs = require("fs");
	let buf = ""; process.stdin.on("data", (d) => { buf += d; });
	process.stdin.on("end", () => {
		let best = null;
		for (const p of buf.split("\0")) {
			if (!p) continue;
			let st, head;
			try { st = fs.statSync(p); head = JSON.parse(fs.readFileSync(p, "utf8").split("\n", 1)[0]); } catch { continue; }
			const m = head?.payload;
			if (!m?.session_id || m.cwd !== process.argv[1]) continue;   // 같은 자리에서 띄운 세션만
			if (!best || st.mtimeMs > best.t) best = { t: st.mtimeMs, id: m.session_id };
		}
		if (best) console.log(best.id);
	});' "$PWD" 2>/dev/null
	}

	# **codex 를 감싸지 않는다.** 예전에는 `script -qe` 로 TUI 출력을 파일에 받아 "usage limit"
	# 문자열을 찾았다. 두 가지가 무너졌다.
	#  (1) 이중 PTY 라 codex 가 종료하며 보내는 터미널 질의·복구 시퀀스가 중계되지 못하고 화면에
	#      raw 로 쏟아진다 (실측: `[>4;0m[>7u]10;?\]11;?\` — 사용자에게는 그냥 깨진 쓰레기다).
	#  (2) TUI 는 매 프레임 화면 전체를 다시 그리므로 transcript 가 세션당 수 MB 로 자란다
	#      (실측: 세션 6개 46MB). 그걸 grep 해서 한도를 *추측* 했다.
	# 한도는 추측할 게 아니라 **물어보면 되는 것**이다 — 아래에서 API 잔량으로 판정한다.
	command codex $BYPASS "$@"
	rc=$?

	# 세션이 회전시킨 토큰을 슬롯에 되돌려 쓴다. 이걸 빠뜨리면 슬롯이 이미 소비된 refresh
	# token 을 든 채 남고, 다음 마운트에서 계정이 통째로 죽는다 (token_revoked).
	if [ "$skip" -eq 0 ]; then node "$AUTH" sync --quiet || true; fi

	# 비정상 종료면 **계정 때문인지 API 에 물어본다.** preflight 가 현재 슬롯 잔량을 읽고,
	# 소진이면 남은 슬롯으로 갈아끼운다 — 즉 "실제로 갈아끼워졌다" 가 곧 "한도로 죽었다" 의 증거다.
	# 문자열 매칭이 사라지니 TUI 상태줄·지나간 문구·대화 내용으로 오탐할 일이 없다.
	if [ "$skip" -eq 0 ] && [ "$retry_after_quota" -eq 1 ] && [ "$rc" -ne 0 ]; then
		case "$rc" in
			130|143)
				# 인터럽트는 사용자가 그만두겠다고 말한 것이다. 잔량과 무관하게 재시작하지 않는다.
				;;
			*)
				live_auth="${CODEX_HOME:-$HOME/.codex}/auth.json"
				acct() { node -e 'try { console.log(JSON.parse(require("fs").readFileSync(process.argv[1], "utf8")).tokens?.account_id ?? "") } catch {}' "$1" 2>/dev/null; }
				sid="$(find_session_id)" || sid=""
				before="$(acct "$live_auth")"
				node "$AUTH" preflight --force || true
				after="$(acct "$live_auth")"
				if [ -n "$before" ] && [ -n "$after" ] && [ "$before" != "$after" ]; then
					# 여기까지 왔으면 API 가 소진을 확인하고 계정이 실제로 갈렸다. 그래도 사람이
					# 이길 수 있게 잠깐 기다린다 — 아무 키나 누르면 그만둔다.
					confirm_secs="${DSCODEX_CONFIRM_SECS:-3}"
					go=1
					if [ "$confirm_secs" -gt 0 ] && [ -t 0 ] && [ -t 1 ]; then
						printf 'dscodex: 한도로 끊겼다 — %s초 뒤 남은 계정으로 대화를 이어서 재개한다. 그만두려면 아무 키나: ' "$confirm_secs" >&2
						if read -r -t "$confirm_secs" -n 1 _dummy; then
							printf '\ndscodex: 재개를 취소했다. 계정은 갈아끼워 뒀으니 다음에 codex 를 치면 새 계정으로 뜬다.\n' >&2
							go=0
						else
							printf '\n' >&2
						fi
					fi
					if [ "$go" -eq 1 ]; then
						if [ -n "$sid" ]; then
							echo "dscodex: 남은 슬롯으로 갈아끼우고 그 대화를 이어서 재개한다 (${sid})." >&2
							command codex resume $BYPASS "$sid"
						else
							echo "dscodex: 남은 슬롯으로 전환해 새 세션을 시작한다 (이어갈 대화를 못 찾았다)." >&2
							command codex $BYPASS "$@"
						fi
						rc=$?
						node "$AUTH" sync --quiet || true
					fi
				fi
				;;
		esac
	fi

	[ -z "$marker" ] || rm -f "$marker"
	exit "$rc"
}

main "$@"; exit $?   # 같은 줄에서 끝낸다 — bash 가 이 뒤의 바이트를 읽지 않는다
