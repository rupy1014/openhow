#!/usr/bin/env node
// codex-auth — Codex CLI 의 ChatGPT 계정을 슬롯으로 갈아끼운다. 외부 도구 의존 없음.
//
// 공식 codex 는 계정이 하나다: `codex login` 은 단일 계정이고 `codex logout` 은 통째로 지운다.
// 이 스크립트는 계정별 auth.json 을 슬롯 파일로 보관하고 ~/.codex/auth.json 을 갈아끼운다.
//
// 슬롯은 **스냅샷**이다. codex 가 세션 중 refresh token 을 회전시키면 live 에만 새 토큰이
// 남고 슬롯은 옛 것을 든다. 그 옛 복사본으로 live 를 덮으면 이미 회전된 refresh token 을
// 다시 제시하게 되고, OpenAI 의 재사용 탐지가 그 계정의 토큰 패밀리를 통째로 폐기한다
// (token_revoked → 재로그인 외에 복구 불가). 그래서 **전환 전에 항상 write-back** 한다.
//
// 사용: codex-auth.mjs list|current|check|use <slot>|sync|add <slot>|adopt [slot]|quota|usage|next|preflight|lane <...>|remove <slot>
// adopt 는 지금 live 에 로그인된 계정을 슬롯으로 보관한다 (슬롯 밖에서 codex login 한 계정 편입).
// preflight 는 세션을 띄우기 직전 자동 전환이다 — dscodex.sh 가 codex 를 띄우기 전에 부른다.
import { spawn, spawnSync } from "node:child_process";
import {
	chmodSync, copyFileSync, existsSync, mkdirSync, mkdtempSync, readFileSync,
	readdirSync, realpathSync, renameSync, rmSync, statSync, symlinkSync, writeFileSync,
} from "node:fs";
import { homedir, platform, tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const HOME = homedir();
const CODEX_HOME = process.env.CODEX_HOME || join(HOME, ".codex");
const LIVE = join(CODEX_HOME, "auth.json");
const CONFIG = join(CODEX_HOME, "config.toml");

// 저장소: 환경변수 → 자기 경로 → omx 저장소(있으면 그대로 입양) → 자기 경로 생성.
// omx 를 쓰던 머신에서 슬롯을 복사해 두 벌로 만들면, 낡은 쪽이 live 를 덮는 순간
// 위의 token_revoked 경로가 그대로 열린다. 그래서 옮기지 않고 같은 저장소를 공유한다.
function resolveDir() {
	if (process.env.CODEX_AUTH_DIR) return process.env.CODEX_AUTH_DIR;
	const own = join(HOME, ".config", "codex-auth");
	if (existsSync(own)) return own;
	const omx = join(HOME, ".omx", "auth");
	if (existsSync(join(omx, "slots.json"))) return omx;
	return own;
}

const DIR = resolveDir();
const META = join(DIR, "slots.json");
const LOCK = join(DIR, ".lock");
const SLOT_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;

// 사람이 그대로 붙여넣을 수 있는 형태로 찍는다. `add cooper.larkin` 만 찍으면
// 그게 어느 명령의 서브커맨드인지 알 수 없어 매번 경로를 되찾아야 한다.
const SELF = (() => {
	const real = fileURLToPath(import.meta.url);
	// 설치본이 레포로 심링크된 머신에서는 실경로가 레포 안을 가리킨다. 사람이 기억하는 건
	// 설치 경로 쪽이므로, 같은 파일이면 그쪽을 찍는다.
	const installed = join(HOME, ".claude", "skills", "codex-auth", "scripts", "codex-auth.mjs");
	let p = real;
	try { if (realpathSync(installed) === realpathSync(real)) p = installed; } catch {}
	return p.startsWith(HOME) ? `~${p.slice(HOME.length)}` : p;
})();
const AUTH_CMD = `node ${SELF}`;

// ── 레인 (세션별 격리 CODEX_HOME) ───────────────────────────────────────
// 세션이 전부 ~/.codex/auth.json 하나를 공유하면 한 계정이 소진될 때 **전부 같이 죽는다**
// (실측 2026-08-28: 슬롯이 8개 살아 있는데 세션 5개가 한 계정을 써서 동시에 만료됐다).
// 레인은 `~/.codex` 의 모든 항목을 심링크하고 **auth.json 만 실파일**로 두는 홈이다 —
// config·hooks·MCP·sessions 는 원본 그대로 공유되고 계정만 갈린다.
// 이 스크립트는 이미 CODEX_HOME 으로 LIVE/CONFIG 를 잡으므로, 레인 홈을 주고 부르면
// 그 레인의 계정에 대해 평소 로직이 그대로 돈다.
const LANES = process.env.CODEX_LANES_DIR || join(HOME, ".codex-lanes");
const LANE_FILE = join(CODEX_HOME, "lane.json");
const inLane = () => existsSync(LANE_FILE);
const readLane = () => { try { return readJson(LANE_FILE); } catch { return {}; } };

// "현재 슬롯" 은 레인 안에서는 그 레인의 것이다. 전역 meta 를 쓰면 레인 A 의 전환이
// 레인 B 의 기록을 덮어 두 레인이 서로를 잘못된 계정으로 안내한다.
function currentSlotGet() {
	if (inLane()) return readLane().slot ?? null;
	return loadMeta().currentSlot;
}
function currentSlotSet(slot) {
	if (inLane()) {
		writeJson(LANE_FILE, { ...readLane(), slot, updatedAt: new Date().toISOString() });
		return;
	}
	const m = loadMeta();
	m.currentSlot = slot;
	saveMeta(m);
}

// 한 슬롯을 두 레인이 동시에 쓰면 각자 refresh token 을 회전시켜 서로를 죽인다
// (재사용 탐지가 그 계정의 토큰 패밀리를 통째로 폐기한다). 그래서 슬롯은 배타 대여다.
// 주인이 죽은 레인은 대여가 아니다 — pid 로 확인한다.
function leaseHolders() {
	const held = new Map();
	if (!existsSync(LANES)) return held;
	const mine = inLane() ? readLane().pid : null;
	for (const d of readdirSync(LANES)) {
		let l; try { l = readJson(join(LANES, d, "lane.json")); } catch { continue; }
		if (!l.slot || !l.pid || l.pid === mine) continue;
		try { process.kill(l.pid, 0); } catch { continue; }
		held.set(l.slot, { pid: l.pid, lane: d });
	}
	return held;
}

const die = (m) => { console.error(`codex-auth: ${m}`); process.exit(1); };
const readJson = (p) => JSON.parse(readFileSync(p, "utf8"));
const slotPath = (s) => join(DIR, `${s}.json`);

function writeJson(p, obj) {
	const tmp = `${p}.tmp.${process.pid}`;
	writeFileSync(tmp, `${JSON.stringify(obj, null, 2)}\n`, { mode: 0o600 });
	renameSync(tmp, p);
}

function initDir() {
	if (!existsSync(DIR)) mkdirSync(DIR, { recursive: true, mode: 0o700 });
	if (!existsSync(META)) writeJson(META, { version: 1, currentSlot: null, slots: [] });
}

// 메타데이터 스키마는 omx auth 와 같게 유지한다 — 같은 저장소를 공유하므로.
function loadMeta() {
	initDir();
	const m = readJson(META);
	m.slots ??= [];
	return m;
}

function saveMeta(m) { writeJson(META, m); }

function touchSlot(meta, slot, fields) {
	const now = new Date().toISOString();
	let row = meta.slots.find((s) => s.slot === slot);
	if (!row) { row = { slot, createdAt: now }; meta.slots.push(row); }
	Object.assign(row, { updatedAt: now, ...fields });
	meta.slots.sort((a, b) => a.slot.localeCompare(b.slot));
}

function listSlots() {
	if (!existsSync(DIR)) return [];
	return readdirSync(DIR)
		.filter((f) => f.endsWith(".json") && f !== "slots.json" && !f.includes(".tmp."))
		.map((f) => f.replace(/\.json$/, ""))
		.sort();
}

// ── 토큰 들여다보기 (네트워크·쿼터 안 씀) ────────────────────────────────
const decodeJwt = (t) => {
	try { return JSON.parse(Buffer.from(String(t).split(".")[1], "base64url").toString()); }
	catch { return null; }
};
const idClaims = (auth) => decodeJwt(auth?.tokens?.id_token) ?? {};
const emailOf = (auth) => idClaims(auth).email ?? "-";
const accountOf = (auth) => auth?.tokens?.account_id ?? null;
// access token 의 만료. **살아있음의 근거로 쓰면 안 된다** — refresh token 이 폐기돼도
// 이미 발급된 access token 의 exp 는 미래로 남는다. "만료됐다" 는 판정에만 쓴다.
const accessExpiresAt = (auth) => {
	const exp = decodeJwt(auth?.tokens?.access_token)?.exp;
	return exp ? exp * 1000 : null;
};
const accessExpired = (auth) => {
	const at = accessExpiresAt(auth);
	return at === null ? null : at < Date.now();
};
// 곧 만료면 조회가 refresh 를 유발한다. refresh token 은 1회용이라, 같은 토큰을 두 곳에서
// 동시에 회전시키면 재사용 탐지가 계정을 통째로 폐기한다 — 그 상황을 피하는 판정에 쓴다.
const refreshImminent = (auth) => {
	const at = accessExpiresAt(auth);
	return at === null ? true : at - Date.now() < 10 * 60_000;
};
// last_refresh 가 id_token 의 iat 보다 미래로 밀려 있으면 codex 가 "방금 갱신했다"고 믿고
// 영영 갱신하지 않는다 → access token 이 만료되는 순간 슬롯이 죽는다.
const refreshDrift = (auth) => {
	const iat = idClaims(auth).iat;
	if (!iat || !auth.last_refresh) return null;
	return Math.round((Date.parse(auth.last_refresh) - iat * 1000) / 1000);
};

// ── 실행 중인 codex 감지 ────────────────────────────────────────────────
// argv 문자열 매칭(pgrep -f 'codex')은 명령줄에 "codex" 가 들어간 남의 셸까지 잡는다
// (에이전트가 띄운 zsh -c '... codex ...' 가 흔하다). comm 도 못 쓴다 — codex 가
// node 래퍼면 comm 은 "node" 고, macOS 의 comm 은 15자에서 잘린다.
// 그래서 **argv 의 실행 토큰**만 본다: 인터프리터면 그 다음 토큰이 진짜 실행 파일이다.
const PS_FIXTURE = process.env.CODEX_AUTH_PS_FIXTURE;   // 테스트 주입구. 실제 실행에선 안 쓴다.
// ps 가 없으면 codexProcs() 는 **빈 배열**을 주고, 코드는 그걸 "도는 codex 가 없다" 로 읽는다.
// 즉 전환 가드가 조용히 꺼진다 (Windows 네이티브). 조용히 사라진 안전판이 가장 나쁘므로
// check 가 이걸 따로 말한다 — 자세한 건 WINDOWS.md.
const psAvailable = () => Boolean(PS_FIXTURE) ||
	spawnSync("ps", ["-Ao", "pid="], { encoding: "utf8" }).status === 0;
const psLines = () => (PS_FIXTURE
	? readFileSync(PS_FIXTURE, "utf8")
	: spawnSync("ps", ["-Ao", "pid=,args="], { encoding: "utf8" }).stdout || "");

// 종류를 나누는 이유: "codex 가 하나라도 살아 있으면 거부" 로는 전환이 **영원히** 안 된다.
// Claude Code 의 codex 플러그인이 세션 내내 `codex app-server` 브로커를 띄워 두기 때문이다.
// 실측 (2026-08-19): 상주 브로커 2개 때문에 `next` 가 항상 exit 1 이었다 — 쿼터가 0인데도
// 자동 전환이 안 되던 것의 정체가 이 가드다. 예전 omx 판은 `pgrep -f 'codex exec'` 여서 안 걸렸다.
// 서브커맨드는 "첫 비플래그 토큰" 으로 뽑지 않는다 — `codex --model x exec` 처럼 값을 받는
// 플래그가 앞에 오면 그 값을 서브커맨드로 읽는다. 알려진 키워드가 argv 에 있는지만 본다.
const SERVER_SUBCMDS = new Set(["app-server", "mcp", "mcp-server", "proto"]);
function classifyProc(rest) {
	if (rest.includes("exec")) return "exec";
	if (rest.some((t) => SERVER_SUBCMDS.has(t))) return "server";
	return "session";
}

function codexProcs() {
	return psLines().split("\n").map((l) => l.trim()).filter(Boolean)
		.map((l) => {
			const m = l.match(/^(\d+)\s+(.*)$/);
			if (!m) return null;
			const tok = m[2].split(/\s+/);
			let i = 0;
			if (/(^|\/)(node|bun|deno)$/.test(tok[0] ?? "")) { i = 1; while (tok[i]?.startsWith("-")) i++; }
			return { pid: +m[1], args: m[2], exe: tok[i] ?? "", kind: classifyProc(tok.slice(i + 1)) };
		})
		.filter((p) => p && p.pid !== process.pid && /(^|\/)codex$/.test(p.exe));
}

// ── 전환 가드 ───────────────────────────────────────────────────────────
// 막아야 하는 건 "codex 가 살아 있다" 가 아니라 두 가지다.
//  (1) 진행 중인 `codex exec` 배치 — 레인이 auth 를 다시 읽는 순간 account id 가 안 맞으면 죽는다.
//      한 레인 살리려다 아홉을 죽이므로 무조건 막는다.
//  (2) **토큰 회전 레이스** — refresh token 은 1회용이다. 살아있는 codex 가 갱신하는 순간에
//      전환이 겹치면 회전된 새 토큰이 live 에만 남았다가 덮여 사라지고, 나가는 슬롯은 이미 쓴
//      토큰을 들고 남는다 → 다음 마운트에서 token_revoked. 회전은 access token 만료가
//      임박했을 때만 일어나므로 **시간**으로 판정한다.
// app-server 브로커와 대화형 세션은 상주한다 — 존재만으로 막으면 기능이 사라진다. 알리고 진행한다.
const RACE_MIN = 30;
const refreshRace = (auth) => {
	const at = accessExpiresAt(auth);
	return at === null ? true : at - Date.now() < RACE_MIN * 60_000;   // 못 읽으면 보수적으로 레이스로 본다
};

// 막을 이유를 **문자열로 돌려준다.** die 하는 쪽(use/next)과 넘어가는 쪽(preflight)이
// 같은 정책을 봐야 한다 — 두 벌로 두면 한쪽만 고치게 된다.
function switchBlocker(outgoing) {
	const procs = codexProcs();
	if (!procs.length) return null;
	const label = (ps) => ps.map((p) => `${p.pid}(${p.kind})`).join(", ");
	const exec = procs.filter((p) => p.kind === "exec");
	if (exec.length) return { kind: "exec", msg: `codex exec 배치가 돌고 있다 (pid ${label(exec)})`, procs };
	if (outgoing && refreshRace(outgoing)) return { kind: "race", msg: `나가는 계정의 토큰 갱신이 ${RACE_MIN}분 안이고 codex 가 돌고 있다 (pid ${label(procs)})`, procs };
	return null;
}

function guardSwitch(force, outgoing) {
	const procs = codexProcs();
	if (!procs.length) return;
	const label = (ps) => ps.map((p) => `${p.pid}(${p.kind})`).join(", ");
	if (force) { console.error(`경고: codex 실행 중인데 --force 로 진행한다 (pid ${label(procs)}) — 그 세션은 죽을 수 있다`); return; }
	const block = switchBlocker(outgoing);
	if (block?.kind === "exec") {
		die(`거부: ${block.msg}.\n` +
			"  전환은 live auth.json 을 통째로 갈아끼운다. 레인이 auth 를 다시 읽는 순간 account id 가\n" +
			"  안 맞으면 그 레인은 auth reload 를 건너뛰고 죽는다 — 한 레인 살리려다 아홉을 죽인다.\n" +
			"  끝난 뒤에 전환하라 (정말 급하면 --force).");
	}
	if (block?.kind === "race") {
		die(`거부: ${block.msg}.\n` +
			"  지금 갈아끼우면 그 프로세스가 회전시킨 refresh token 이 live 에만 남았다가 덮여 사라진다\n" +
			"  → 나가는 슬롯이 token_revoked 로 죽는다. codex 를 끄고 'sync' 한 뒤 전환하라 (--force 는 그 위험 감수).");
	}
	console.error(`  참고: codex ${procs.length}개가 돌고 있다 (pid ${label(procs)}) — 재시작 전까지 옛 계정을 계속 쓴다.`);
}

// ── 락 (전환은 read-modify-write 라 두 세션이 겹치면 서로의 스냅샷을 덮는다) ──
function lockAcquire(soft = false) {
	initDir();
	try { mkdirSync(LOCK); }
	catch {
		const owner = Number(readFileSync(join(LOCK, "pid"), "utf8").trim() || 0);
		let alive = false;
		try { process.kill(owner, 0); alive = true; } catch { alive = false; }
		// soft 는 "못 하면 그냥 넘어가는" 호출자용(preflight). 거기서 die 하면 codex 가 안 뜬다.
		if (alive && soft) return false;
		if (alive) die(`다른 codex-auth 가 실행 중이다 (pid ${owner}). 끝난 뒤 다시 시도하라`);
		rmSync(LOCK, { recursive: true, force: true });   // 주인이 죽었으면 남은 락은 쓰레기다
		mkdirSync(LOCK);
	}
	writeFileSync(join(LOCK, "pid"), String(process.pid));
	const release = () => { try { rmSync(LOCK, { recursive: true, force: true }); } catch {} };
	process.on("exit", release);
	for (const sig of ["SIGINT", "SIGTERM"]) process.on(sig, () => { release(); process.exit(130); });
	return true;
}

// ── 전제조건: 파일 기반 자격증명 저장소 ─────────────────────────────────
// codex 가 macOS 키체인 모드면 auth.json 을 갈아끼워도 통째로 무시된다.
// 전환이 "성공했다"고 찍히고 실제로는 계정이 안 바뀌는 게 가장 나쁜 실패다.
function credStore() {
	if (!existsSync(CONFIG)) return null;
	const m = readFileSync(CONFIG, "utf8").match(/^\s*cli_auth_credentials_store\s*=\s*"([^"]+)"/m);
	return m ? m[1] : null;
}

function requireFileStore() {
	const v = credStore();
	if (v === "file") return;
	if (v === null && platform() !== "darwin") return;   // 비-macOS 는 파일이 기본이다
	die(`자격증명 저장소가 파일이 아니다 (config: ${v ?? "미설정"}).\n` +
		"  키체인 모드면 auth.json 을 갈아끼워도 codex 가 무시한다. 먼저 이 줄을 넣어라:\n" +
		`    echo 'cli_auth_credentials_store = "file"' >> ${CONFIG}\n` +
		"  (계정 N개의 refresh token 이 평문 JSON(0600)에 모인다 — 동작 전제라 끌 수 없다.)");
}

// ── write-back: 갱신된 토큰을 슬롯에 되돌려 쓴다 ────────────────────────
// src(live 또는 임시 홈의 auth.json)에서 슬롯으로. codex 가 토큰을 회전시킨 뒤
// 이걸 빠뜨리면 슬롯이 옛 refresh token 을 든 채 남고, 다음 마운트에서 죽는다.
function writeBackFrom(srcPath, slot) {
	const sp = slotPath(slot);
	if (!existsSync(sp) || !existsSync(srcPath)) return { status: "missing", slot };
	const src = readJson(srcPath);
	const stored = readJson(sp);
	// 계정이 다르면 절대 쓰지 않는다 — 남의 슬롯에 다른 계정 토큰을 박으면 두 계정을 한꺼번에 잃는다.
	if (!accountOf(src) || accountOf(src) !== accountOf(stored)) {
		return { status: "mismatch", slot, live: accountOf(src), stored: accountOf(stored) };
	}
	if (src.tokens?.refresh_token === stored.tokens?.refresh_token &&
		src.tokens?.access_token === stored.tokens?.access_token) return { status: "unchanged", slot };
	// src 가 슬롯보다 **낡은** 스냅샷이면 쓰지 않는다. 슬롯이 이미 회전된 토큰을 들고 있는데
	// 낡은 live 로 되돌리면 이미 소비된 refresh token 이 부활해 다음 마운트에서 계정을 죽인다.
	// (quota 조회가 슬롯만 갱신하고 live 를 못 따라간 상황에서 실제로 열리는 경로다.)
	const ts = (a) => Date.parse(a?.last_refresh ?? "") || 0;
	if (ts(src) && ts(stored) && ts(src) < ts(stored)) {
		return { status: "stale", slot, srcAt: src.last_refresh, storedAt: stored.last_refresh };
	}
	writeJson(sp, src);
	return { status: "updated", slot };
}

function syncBack() {
	const slot = currentSlotGet();
	if (!slot) return { status: "no-current" };
	if (!existsSync(LIVE)) return { status: "missing", slot };
	return writeBackFrom(LIVE, slot);
}

function mount(slot) {
	copyFileSync(slotPath(slot), LIVE);
	chmodSync(LIVE, 0o600);
	const meta = loadMeta();
	touchSlot(meta, slot, { lastUsedAt: new Date().toISOString() });
	saveMeta(meta);
	currentSlotSet(slot);
}

// live 에 로그인된 계정을 슬롯 스냅샷으로 보관한다. 반환: 슬롯 이름 (못 하면 null).
// 슬롯 밖에서 `codex login` 을 하면 live 가 어느 슬롯도 아닌 상태가 되고, 그 토큰은
// 사본이 없어서 다음 mount 한 번에 유실된다. 그 전에 붙잡아 두는 것이 이 함수다.
// name 을 주면 그 이름만 쓴다 (다른 계정이 이미 그 이름이면 null — 남의 슬롯을 덮지 않는다).
// 안 주면 이메일 앞부분을 쓰고, 이름이 겹치면 접미사를 붙인다 — 자동 경로는 멈추면 안 된다.
function adoptLive(name) {
	if (!existsSync(LIVE)) return null;
	let auth; try { auth = readJson(LIVE); } catch { return null; }
	const acct = accountOf(auth);
	if (!acct) return null;
	const mine = (s) => { try { return accountOf(readJson(slotPath(s))) === acct; } catch { return false; } };
	// 같은 계정이 이미 슬롯에 있으면 그 슬롯을 갱신한다. 한 계정이 두 슬롯에 있으면
	// 한쪽이 토큰을 회전시킬 때 다른 쪽이 죽는다 — 슬롯이 무더기로 죽는 바로 그 경로다.
	const dup = listSlots().find(mine);
	let slot = name ?? dup ?? String(emailOf(auth)).split("@")[0];
	if (!SLOT_RE.test(slot)) return null;
	const takenByOther = (t) => existsSync(slotPath(t)) && !mine(t);   // 손상 파일도 안 덮는다
	if (takenByOther(slot)) {
		if (name) return null;                                          // 이름을 골랐으면 조용히 바꾸지 않는다
		const base = slot;
		for (let i = 2; takenByOther(slot); i++) slot = `${base}-${i}`;
	}
	copyFileSync(LIVE, slotPath(slot));
	chmodSync(slotPath(slot), 0o600);
	const meta = loadMeta();
	touchSlot(meta, slot, { lastUsedAt: new Date().toISOString() });
	saveMeta(meta);
	currentSlotSet(slot);
	forgetDead(slot);
	return slot;
}

// live 가 어느 슬롯인지 기록이 없을 때 account_id 로 되짚는다.
function identifyLive() {
	if (!existsSync(LIVE)) return [];
	const id = accountOf(readJson(LIVE));
	if (!id) return [];
	return listSlots().filter((s) => { try { return accountOf(readJson(slotPath(s))) === id; } catch { return false; } });
}

function liveMatchesSlot(slot) {
	try {
		if (!slot || !existsSync(LIVE) || !existsSync(slotPath(slot))) return false;
		const live = accountOf(readJson(LIVE));
		const stored = accountOf(readJson(slotPath(slot)));
		return Boolean(live && stored && live === stored);
	} catch { return false; }
}

// ── app-server 조회 (account/rateLimits/read · account/usage/read) ─────
// 실제 API 조회이고 모델 쿼터는 안 쓴다. **임시 CODEX_HOME 에 슬롯을 복사해 물으므로
// live auth.json 을 건드리지 않는다** — 그래서 codex 배치가 도는 중에도 안전하다.
// (검증: 임시 홈으로 읽은 값이 마운트해서 읽은 값과 같았다 — 100%/3% 그대로.)
// 주의: usedPercent=0 + resetsAt=지금+창길이 는 "값 없음" 이 아니라 **이번 창에서 아직
// 안 썼다(잔량 100%)** 는 실제 응답이다. 실측으로 확인했다 — 그 상태의 슬롯으로 exec 이 돈다.
function appServerCall(home, method, params = {}) {
	return new Promise((resolve) => {
		// cwd 도 임시 홈으로 준다. codex 는 cwd 를 프로젝트 루트로 보고 훅·래퍼가 거기에
		// 상태 디렉토리(.omx 등)를 만든다 — 남의 레포에 부산물을 흘리지 않는다.
		const proc = spawn("codex", ["app-server"], {
			stdio: ["pipe", "pipe", "pipe"],
			cwd: home,
			env: { ...process.env, CODEX_HOME: home },
		});
		const pending = new Map();
		let buf = "", err = "", id = 1;
		// **rpcError 를 버리지 마라.** JSON-RPC 에러 본문이 "인증 폐기 / 쿼터 / 네트워크" 를 가르는
		// 유일한 단서다. 이걸 null 로 뭉개서 전부 "조회 실패 (인증 폐기/네트워크)" 로 보이던 게
		// 오진의 원인이었다 — stderr 가 비는 슬롯은 이유가 아예 안 남았다.
		const done = (v, rpcError = null) => {
			try { proc.kill(); } catch {}
			resolve({ result: v, err: err.trim().split("\n").slice(-2).join(" "), rpcError });
		};
		const timer = setTimeout(() => done(null, "timeout: 25초 안에 응답이 없었다"), 25000);
		proc.on("error", (e) => { clearTimeout(timer); done(null, `codex 실행 실패: ${e.message}`); });
		proc.stderr.on("data", (d) => { err += d.toString(); });
		proc.stdout.on("data", (d) => {
			buf += d.toString();
			let i;
			while ((i = buf.indexOf("\n")) >= 0) {
				const line = buf.slice(0, i).trim();
				buf = buf.slice(i + 1);
				if (!line) continue;
				let msg; try { msg = JSON.parse(line); } catch { continue; }
				if (msg.id !== undefined && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
			}
		});
		const call = (m, p = {}) => new Promise((res) => {
			const rid = id++;
			pending.set(rid, res);
			proc.stdin.write(`${JSON.stringify({ jsonrpc: "2.0", id: rid, method: m, params: p })}\n`);
		});
		(async () => {
			await call("initialize", { clientInfo: { name: "codex-auth", title: "codex-auth", version: "1.0.0" } });
			proc.stdin.write(`${JSON.stringify({ jsonrpc: "2.0", method: "initialized", params: {} })}\n`);
			const res = await call(method, params);
			clearTimeout(timer);
			done(res?.result ?? null, res?.error?.message ?? null);
		})().catch((e) => { clearTimeout(timer); done(null, e?.message ?? null); });
	});
}

// 슬롯 하나를 임시 홈에 복사해 조회한다. config 를 같이 넣어야 codex 가 키체인이 아니라
// 이 디렉토리의 auth.json 을 본다. 조회 중 토큰이 갱신되면 그 결과를 슬롯에 되돌려 쓴다.
// quota 와 usage 가 같은 절차를 쓰므로 메서드만 갈아끼운다 — 두 벌로 두면 한쪽만 고치게 된다.
async function askAsSlot(slot, auth, method) {
	const isCurrent = currentSlotGet() === slot;
	const running = codexProcs().length > 0;
	// 돌고 있는 codex 가 이 슬롯의 토큰을 쓰는데 곧 갱신이 필요한 상태면 건드리지 않는다.
	// 임시 홈의 갱신은 그 프로세스와 조율되지 않아, 같은 refresh token 을 두 번 회전시킨다.
	if (isCurrent && running && refreshImminent(auth)) return { skip: "실행 중인 codex 가 쓰는 슬롯이고 토큰 갱신이 임박했다" };
	const home = mkdtempSync(join(tmpdir(), "codex-auth-"));
	try {
		copyFileSync(slotPath(slot), join(home, "auth.json"));
		chmodSync(join(home, "auth.json"), 0o600);
		writeFileSync(join(home, "config.toml"), 'cli_auth_credentials_store = "file"\n');
		const { result, err, rpcError } = await appServerCall(home, method);
		// 조회가 토큰을 회전시켰으면 슬롯에 반영하고, 그 슬롯이 지금 마운트돼 있으면 live 도 같이
		// 맞춘다. 안 맞추면 live 가 **이미 소비된** refresh token 을 든 채 남고, 다음 sync 가 그
		// 낡은 live 로 슬롯을 덮어 계정을 죽인다. 같은 계정의 더 새 토큰이라 codex 가 돌고 있어도
		// auth reload 가 거부되지 않는다 — 그래서 실행 여부가 아니라 **account id** 만 확인한다.
		let repaired = false;
		if (writeBackFrom(join(home, "auth.json"), slot).status === "updated" && isCurrent) {
			const liveAcct = existsSync(LIVE) ? accountOf(readJson(LIVE)) : null;
			if (liveAcct && liveAcct === accountOf(readJson(slotPath(slot)))) {
				copyFileSync(slotPath(slot), LIVE);
				chmodSync(LIVE, 0o600);
				repaired = true;
			}
		}
		return { result, err, rpcError, repaired };
	} finally { rmSync(home, { recursive: true, force: true }); }
}

// 표를 깨지 않게 이유를 한 줄로 줄인다. 원문은 --json 의 detail 에 그대로 남는다.
// codex 는 401 본문을 통째로 message 에 담아 준다 — 쓸모 있는 건 그 안의 code 뿐이다.
function shortReason(text) {
	const t = String(text ?? "").replace(/\s+/g, " ").trim();
	if (!t) return "";
	const code = t.match(/"code":\s*"([a-z_]+)"/i);
	if (code) return code[1];
	const status = t.match(/\b([45]\d\d)\b/);
	return status ? `${status[1]} ${t.slice(0, 60)}` : t.slice(0, 80);
}

// 실패 문구로 슬롯 상태를 가른다. codex-accounts 가 표로 갖고 있던 구분인데 포팅에서 빠졌고,
// 그 결과 "인증 폐기(사람이 재로그인)" 와 "네트워크(재시도)" 가 같은 한 줄로 보였다.
function failureState(text) {
	const t = String(text ?? "");
	if (/token_revoked|token_invalidated|refresh token was revoked|authentication token has been invalidated|\b401\b|unauthorized/i.test(t)) return "auth-dead";
	if (/usage limit|rate.?limit|\bquota\b|\b429\b/i.test(t)) return "quota";
	if (!t.trim()) return "unknown";
	return "network";
}

const STATE_LABEL = {
	"auth-dead": "인증 폐기 — 재로그인 필요",
	quota: "쿼터 소진",
	network: "조회 실패 (네트워크/알 수 없음)",
	unknown: "조회 실패 (이유가 안 남았다)",
	"spend-limit": "지출 한도 도달",
	corrupt: "슬롯 파일 손상",
};

// 슬롯 하나의 쿼터. 한 칸만 필요한 호출자(preflight)가 전 슬롯 sweep 을 돌지 않게 쪼개 뒀다
// (실측: 슬롯 7개 sweep 13초, 1개 1.9초 — launch 앞에 붙는 지연이라 이 차이가 크다).
const QUOTA_FIXTURE = process.env.CODEX_AUTH_QUOTA_FIXTURE;   // 테스트 주입구. 실제 실행에선 안 쓴다.

// Codex는 현재 5시간 창과 장기 창을 primary/secondary로 보낸다. 어떤 쪽이 5시간인지는
// 플랜과 시점에 따라 바뀔 수 있으므로 이름을 가정하지 않고, 둘 다 보존한 뒤 가장 좁은 창을
// 선택 기준으로 쓴다. `windows`를 결과에도 남겨 quota --json 소비자가 판정 근거를 볼 수 있게 한다.
function rateLimitWindows(rateLimits) {
	return ["primary", "secondary"]
		.map((source) => ({ source, value: rateLimits?.[source] }))
		.filter(({ value }) => value && value.usedPercent !== null && value.usedPercent !== undefined)
		.map(({ source, value }) => ({
			source,
			remainingPercent: Math.max(0, 100 - value.usedPercent),
			resetsAt: value.resetsAt ? new Date(value.resetsAt * 1000).toISOString() : null,
			windowMins: value.windowDurationMins ?? null,
		}));
}

function quotaFromRateLimits(slot, auth, rateLimits, repaired = false) {
	const windows = rateLimitWindows(rateLimits);
	const binding = windows.length
		? windows.reduce((a, b) => (b.remainingPercent < a.remainingPercent ? b : a))
		: null;
	return {
		slot, email: emailOf(auth),
		// 지출 한도에 걸린 계정은 쿼터가 남아 있어도 실행이 안 된다 — usable 에서 빼야 한다.
		state: rateLimits.spendControlReached ? "spend-limit" : "ok",
		error: rateLimits.spendControlReached ? STATE_LABEL["spend-limit"] : undefined,
		remainingPercent: binding?.remainingPercent ?? null,
		resetsAt: binding?.resetsAt ?? null,
		windowMins: binding?.windowMins ?? null,
		bindingWindow: binding?.source ?? null,
		windows,
		planType: rateLimits.planType ?? null,
		credits: rateLimits.credits?.unlimited ? "unlimited" : (rateLimits.credits?.hasCredits ? rateLimits.credits.balance : "none"),
		repaired: repaired || undefined,
	};
}

async function quotaRow(slot) {
	let auth;
	try { auth = readJson(slotPath(slot)); } catch { return { slot, state: "corrupt", error: STATE_LABEL.corrupt }; }
	if (QUOTA_FIXTURE) {
		const row = JSON.parse(readFileSync(QUOTA_FIXTURE, "utf8"))[slot];
		if (!row) return { slot, email: emailOf(auth), state: "network", error: STATE_LABEL.network };
		// 기존 정규화 fixture와 실제 RPC 응답 모양 fixture를 모두 받는다. 후자는 새 창이
		// 추가될 때 선택 로직 자체를 검증하는 회귀 테스트용이다.
		if (row.rateLimits) return quotaFromRateLimits(slot, auth, row.rateLimits);
		return { slot, email: emailOf(auth), error: row.state === "ok" ? undefined : STATE_LABEL[row.state], ...row };
	}
	{
		const { result, err, rpcError, skip, repaired } = await askAsSlot(slot, auth, "account/rateLimits/read");
		const rl = result?.rateLimits ?? null;
		if (skip) return { slot, email: emailOf(auth), state: "skipped", error: `건너뜀 (${skip})`, detail: skip };
		if (!rl) {
			const detail = [rpcError, err].filter(Boolean).join(" | ");
			const state = failureState(detail);
			return {
				slot, email: emailOf(auth), state, detail,
				remainingPercent: state === "quota" ? 0 : null,
				error: `${STATE_LABEL[state]}${detail ? ` (${shortReason(detail)})` : ""}`,
			};
		}
		return quotaFromRateLimits(slot, auth, rl, repaired);
	}
}

// 마지막 전수 조회 결과 중 **사람이 손대야 하는 것**만 남긴다. 인증 폐기는 로테이션으로
// 안 살아나므로, launch 때마다 보이지 않으면 몇 주씩 죽은 채로 방치된다. 조회는 비싸고
// (슬롯 11개 ≈ 13초) launch 앞에 붙일 수 없으니, sweep 이 돌 때 적어 두고 그걸 읽는다.
// `.json` 이면 listSlots 가 슬롯으로 세므로 확장자를 쓰지 않는다.
const HEALTH = join(DIR, "health.state");
const readHealth = () => { try { return readJson(HEALTH); } catch { return null; } };
// 폐기 기록은 **끈적하다** — 지우는 근거는 "살아있다(ok)" 하나뿐이다.
// 실측 (2026-08-27): 두 번의 sweep 이 token_invalidated 로 확인한 슬롯이 그 사이 조회에서는
// 침묵(state="network")했고, 그 침묵을 "모른다" 로 읽은 아래 마지막-수단 로직이 그걸 골랐다.
// (그 계정은 나중에 실제로 살아났지만 그건 운이지 근거가 아니다 — 고를 시점엔 폐기가 유일한
// 증거였다.) 조회 실패는 되살아났다는 증거가 아니므로, 지우는 건 ok 조회 하나뿐이다.
function writeHealth(rows) {
	try {
		const known = new Map((readHealth()?.dead ?? []).map((d) => [d.slot, d]));
		const now = new Date().toISOString();
		for (const r of rows) {
			if (r.state === "auth-dead") known.set(r.slot, { slot: r.slot, email: r.email ?? null, since: known.get(r.slot)?.since ?? now });
			else if (r.state === "ok") known.delete(r.slot);   // 조회 실패는 살아났다는 증거가 아니다
		}
		writeJson(HEALTH, { checkedAt: now, dead: [...known.values()] });
	} catch {}
}
const knownDead = () => new Set((readHealth()?.dead ?? []).map((d) => d.slot));
function forgetDead(slot) {
	const h = readHealth();
	if (!h?.dead?.length) return;
	h.dead = h.dead.filter((d) => d.slot !== slot);
	try { writeJson(HEALTH, h); } catch {}
}

// 재로그인 절차를 명령 한 줄로 끝내지 않는다 — device-auth 는 브라우저 계정에 따라
// 엉뚱한 계정이 등록되는 게 가장 흔한 실패고, 그건 명령만 봐서는 알 수 없다.
function printReauth(slots, log = console.log) {
	for (const d of slots) log(`  ${AUTH_CMD} add ${d.slot} --force${d.email ? `   # ${d.email}` : ""}`);
	log("  → 화면에 뜨는 URL 과 코드를 브라우저에서 열고 **그 슬롯의 계정으로** 로그인하면 된다.");
	log("     다른 계정이 로그인된 브라우저면 그 계정이 중복 등록된다 — 시크릿 창을 쓰거나 먼저 로그아웃하라.");
}

async function collectQuota() {
	const meta = loadMeta();
	const rows = [];
	for (const slot of listSlots()) {
		const row = await quotaRow(slot);
		// 순서를 정하는 유일한 tie-breaker 다 (아래 oldestFirst). 표에도 --json 에도 남긴다.
		row.lastUsedAt = meta.slots.find((r) => r.slot === slot)?.lastUsedAt ?? null;
		rows.push(row);
	}
	writeHealth(rows);
	return { currentSlot: currentSlotGet(), slots: rows };
}

// provider는 5시간 한도에 걸렸을 때도 usedPercent=99(남음 1%)를 마지막으로 보낼 수 있다.
// 따라서 1%는 실제 사용 가능 신호가 아니며, 어떤 --min 값도 이 안전 하한 아래로 내릴 수 없다.
const MIN_REMAINING = 2;

// 잔량이 같거나 **아예 못 읽었을 때** 의 순서: 가장 오래 안 쓴 슬롯부터.
// 최근에 쓴 것부터 밟으면 방금 소진시킨 계정을 다시 고른다. 5시간 창은 그 계정을 마지막으로
// 쓴 시점부터 흐르므로, 오래 묵은 슬롯일수록 창이 이미 돌았을 확률이 높다.
// lastUsedAt 이 없는 슬롯(한 번도 안 쓴 것)은 가장 오래된 것으로 본다.
const oldestFirst = (a, b) => String(a.lastUsedAt ?? "").localeCompare(String(b.lastUsedAt ?? ""));

// 다른 레인이 쓰고 있는 슬롯은 후보가 아니다 — 두 세션이 같은 계정을 회전시키면 둘 다 죽는다.
const usableSlots = (rows, min) => {
	const held = leaseHolders();
	return rows
		.filter((r) => r.state === "ok" && (r.remainingPercent ?? 0) >= Math.max(MIN_REMAINING, min) && !held.has(r.slot))
		.sort((a, b) => b.remainingPercent - a.remainingPercent || oldestFirst(a, b));
};

// 쿼터를 못 읽은 슬롯. **"모른다" 는 "못 쓴다" 가 아니다** — 지금까진 이 슬롯들을 통째로
// 버려서, 조회만 실패하고 실제로는 멀쩡한 계정까지 "쓸 수 있는 슬롯이 없다" 로 덮였다.
// 확실한 신호(ok·quota·spend-limit)가 하나도 안 남았을 때의 마지막 수단이고, 순서는 위와
// 같이 가장 오래 안 쓴 것부터다.
// auth-dead 와 corrupt 는 여기 안 들어온다 — 앞은 확실한 신호이고(인증 실패에 슬롯을 도는
// 것이 옛 hotswap 사고다), 뒤는 파일이 깨져서 마운트 자체가 안 된다.
const UNREAD_STATES = ["network", "unknown", "skipped"];
const unreadSlots = (rows) => {
	const dead = knownDead();   // 지난 조회에서 폐기로 확인된 슬롯은 침묵해도 후보가 아니다
	const held = leaseHolders();
	return rows.filter((r) => UNREAD_STATES.includes(r.state) && !dead.has(r.slot) && !held.has(r.slot)).sort(oldestFirst);
};

const fmtLastUsed = (iso) => iso ? iso.slice(0, 16).replace("T", " ") : "쓴 적 없음";
// 못 읽은 슬롯은 잔량이 null 이다. 0% 로 찍으면 "소진됐는데 왜 골랐냐" 로 읽힌다.
const pctLabel = (r) => (r.remainingPercent === null || r.remainingPercent === undefined) ? "잔량 미상" : `${r.remainingPercent}%`;

// 숫자 플래그. 조용히 NaN 으로 넘어가면 임계선이 사라진 채 "동작하는 것처럼" 보인다.
function numArg(argv, flag, dflt) {
	const i = argv.indexOf(flag);
	if (i === -1) return dflt;
	const v = Number(argv[i + 1]);
	if (!Number.isFinite(v) || v < 0) die(`${flag} 는 0 이상의 숫자여야 한다`);
	return v;
}

// ── 커맨드 ──────────────────────────────────────────────────────────────
function cmdList(argv) {
	initDir();
	const meta = loadMeta();
	const slots = listSlots();
	if (argv.includes("--json")) {
		const rows = slots.map((s) => {
			let a; try { a = readJson(slotPath(s)); } catch { return { slot: s, error: "파일 손상" }; }
			return { slot: s, email: emailOf(a), current: currentSlotGet() === s, accountId: accountOf(a), accessExpired: accessExpired(a) };
		});
		console.log(JSON.stringify({ dir: DIR, currentSlot: currentSlotGet(), slots: rows }, null, 2));
		return;
	}
	if (!slots.length) { console.log(`슬롯 없음 (${DIR}) — 'add <이름>' 으로 계정을 넣어라`); return; }
	console.log(`저장소: ${DIR}`);
	console.log(`${"  SLOT".padEnd(24)}${"EMAIL".padEnd(34)}마지막 사용`);
	for (const s of slots) {
		let a; try { a = readJson(slotPath(s)); } catch { console.log(`  ${s.padEnd(22)}(파일 손상)`); continue; }
		const mark = currentSlotGet() === s ? "* " : "  ";
		const last = meta.slots.find((r) => r.slot === s)?.lastUsedAt?.slice(0, 16).replace("T", " ") ?? "-";
		console.log(mark + s.padEnd(22) + emailOf(a).padEnd(34) + last);
	}
	const curSlot = currentSlotGet();
	const drift = existsSync(LIVE) && curSlot && existsSync(slotPath(curSlot)) &&
		readJson(LIVE).tokens?.refresh_token !== readJson(slotPath(curSlot)).tokens?.refresh_token;
	if (drift) console.log("\n  주의: live 토큰이 슬롯 스냅샷과 다르다 (회전됨). 'sync' 로 되돌려 써라.");
}

function cmdCurrent() {
	const cur = currentSlotGet();
	if (!existsSync(LIVE)) { console.log("live auth.json 이 없다 — 로그인된 계정이 없다"); return; }
	const live = readJson(LIVE);
	console.log(`현재 슬롯: ${cur ?? "(기록 없음)"}${inLane() ? `  (레인 ${readLane().pid})` : ""}`);
	console.log(`live 계정 : ${emailOf(live)}  (${accountOf(live)})`);
	if (!cur) {
		const guess = identifyLive();
		if (guess.length) console.log(`  account_id 로 추정: ${guess.join(", ")} — 'use <slot>' 로 기록을 맞춰라`);
	}
}

// 슬롯을 무더기로 죽이는 가장 조용한 경로: 이 머신 밖으로 live auth.json 을 복사해 두고
// 저쪽에서도 codex 를 돌리는 것. refresh token 은 1회용이라 저쪽이 갱신하는 순간 이쪽 사본이
// 죽는다 (반대도 마찬가지). 스킬이 아무리 write-back 을 잘 해도 이 복사기는 못 이긴다.
// 실측 (2026-08-19): `*/2 * * * * rsync ~/.codex/auth.json <remote>:.codex/` 가 걸려 있는
// 머신에서 슬롯 6개 중 5개가 token_invalidated 였다.
function authFanout() {
	const hits = [];
	const cron = spawnSync("crontab", ["-l"], { encoding: "utf8" }).stdout || "";
	for (const line of cron.split("\n")) {
		const t = line.trim();
		if (!t || t.startsWith("#")) continue;
		if (/auth\.json/.test(t) && /codex/i.test(t)) hits.push(`crontab: ${t}`);
	}
	const la = join(HOME, "Library", "LaunchAgents");
	if (existsSync(la)) {
		for (const f of readdirSync(la)) {
			if (!f.endsWith(".plist")) continue;
			try {
				const body = readFileSync(join(la, f), "utf8");
				if (/auth\.json/.test(body) && /codex/i.test(body)) hits.push(`LaunchAgent: ${f}`);
			} catch {}
		}
	}
	return hits;
}

function cmdCheck() {
	initDir();
	const meta = loadMeta();
	let bad = 0;
	const row = (k, v) => console.log(`  ${k}: ${v}`);
	const codex = spawnSync("codex", ["--version"], { encoding: "utf8" });
	codex.status === 0 ? row("codex 바이너리", codex.stdout.trim()) : (row("codex 바이너리", "없음 (npm i -g @openai/codex)"), bad++);
	const store = credStore();
	if (store === "file") row("자격증명 저장소", "file (OK)");
	else if (store === null && platform() !== "darwin") row("자격증명 저장소", "미설정 (비-macOS 기본이 file)");
	else { row("자격증명 저장소", `${store ?? "미설정"} — 전환이 무시된다. config.toml 에 cli_auth_credentials_store = "file"`); bad++; }
	row("저장소", `${DIR}${DIR.includes("/.omx/") ? " (omx 저장소 공유 중)" : ""}`);
	existsSync(LIVE) ? row("live auth.json", `있음 (${emailOf(readJson(LIVE))})`) : (row("live auth.json", "없음 — 로그인 필요"), bad++);
	const curSlot2 = currentSlotGet();
	if (curSlot2) {
		const sp = slotPath(curSlot2);
		if (!existsSync(sp)) { row("현재 슬롯", `${curSlot2} — 슬롯 파일이 없다`); bad++; }
		else {
			const same = existsSync(LIVE) && readJson(LIVE).tokens?.refresh_token === readJson(sp).tokens?.refresh_token;
			row("현재 슬롯", `${curSlot2} ${same ? "(live 와 일치)" : "— live 와 다르다 (토큰 회전): 'sync' 하라"}`);
			if (!same) bad++;
		}
	} else { row("현재 슬롯", "기록 없음 — 'use <slot>' 로 맞춰라"); bad++; }
	// 종류를 나눠 보여준다. exec 만 전환을 막는다 — 상주하는 app-server 브로커까지 막으면
	// 전환이 영원히 안 된다 (그 회귀가 "쿼터 0인데 자동 전환이 안 된다" 로 보였다).
	if (!psAvailable()) {
		row("전환 가드", "⛔ ps 를 못 읽는다 — 도는 codex 를 감지하지 못해 가드가 꺼진다");
		console.log("      codex exec 배치 중에도 전환해 레인을 죽이거나, 토큰 회전 레이스로 계정을 잃을 수 있다.");
		console.log("      Windows 네이티브면 WSL2 를 써라 (skills/codex-auth/WINDOWS.md).");
		bad++;
	}
	const procs = codexProcs();
	if (!procs.length) row("실행 중인 codex", psAvailable() ? "없음 (전환 가능)" : "판정 불가 (ps 없음)");
	else {
		const parts = [["exec", "배치 — 전환 차단"], ["session", "대화형 — 전환은 되지만 옛 계정을 계속 쓴다"], ["server", "app-server/mcp — 전환 안 막음"]]
			.map(([k, d]) => [procs.filter((p) => p.kind === k), d])
			.filter(([ps]) => ps.length)
			.map(([ps, d]) => `${ps.length}× ${d} (pid ${ps.map((p) => p.pid).join(", ")})`);
		row("실행 중인 codex", parts.join(" / "));
	}
	const fan = authFanout();
	if (fan.length) {
		row("auth.json 유출", `${fan.length}건 — 이 머신 밖으로 live 자격증명이 복사되고 있다`);
		for (const h of fan) console.log(`    ${h}`);
		console.log("    저쪽에서도 codex 가 돌면 refresh token 이 거기서 회전한다 → 이쪽 슬롯이 token_revoked 로 죽는다.");
		console.log("    슬롯이 무더기로 죽었다면 이걸 먼저 끊어라. 계정 공유는 파일 복사가 아니라 슬롯을 나눠 갖는 방식이어야 한다.");
		bad++;
	}
	console.log("  슬롯별:");
	for (const s of listSlots()) {
		let a; try { a = readJson(slotPath(s)); } catch { console.log(`    ${s.padEnd(22)} 파일 손상`); bad++; continue; }
		const d = refreshDrift(a);
		const notes = [];
		if (accessExpired(a)) notes.push("access token 만료 (조회는 갱신 후)");
		if (d !== null && Math.abs(d) > 5) { notes.push(`last_refresh 드리프트 ${d}s — 갱신이 멈춘다`); bad++; }
		if ((statSync(slotPath(s)).mode & 0o777) !== 0o600) { notes.push("권한이 600 이 아니다"); bad++; }
		console.log(`    ${s.padEnd(22)} ${emailOf(a).padEnd(32)} ${notes.join(" / ") || "ok"}`);
	}
	// 로컬 파일만 보는 진단이다. 인증이 살아있는지는 여기서 절대 알 수 없다 — 폐기된 계정도
	// 파일은 멀쩡해 보이고 access token 의 exp 도 미래로 남는다.
	if (listSlots().length) console.log("  (여기서 'ok' 는 파일이 멀쩡하다는 뜻이다. 인증 생사는 'quota' 로만 확인된다)");
	process.exit(bad ? 1 : 0);
}

function cmdSync(argv = []) {
	const r = syncBack();
	// dscodex 는 세션 종료 뒤 sync를 부른다. 세션 동안 5시간 쿼터가 바뀔 수 있으므로
	// 이전 launch의 양수 cache를 남기면 다음 plain preflight가 RPC 조회 없이 소진 슬롯을
	// 다시 띄운다. write-back 성공 여부와 무관하게 다음 launch는 새로 확인해야 한다.
	clearPreflightCache();
	const msg = {
		updated: () => `${r.slot}: 갱신된 토큰을 슬롯에 반영했다`,
		unchanged: () => `${r.slot}: 변경 없음`,
		"no-current": () => "현재 슬롯 기록이 없다 — 'use <slot>' 로 맞춰라",
		missing: () => `${r.slot}: 슬롯 파일이나 live auth.json 이 없다`,
		mismatch: () => `account_id 불일치 (live=${r.live} slot=${r.stored}). 안전을 위해 중단 — live 가 다른 계정이다`,
		// 슬롯이 live 보다 새로운 경우다 (quota 조회가 슬롯만 갱신했을 때). 여기서 덮으면
		// 이미 소비된 refresh token 이 부활한다 — 방향이 반대이므로 'use' 로 live 를 맞춘다.
		stale: () => `${r.slot}: live 가 슬롯보다 낡았다 (live ${r.srcAt} < slot ${r.storedAt}) — 슬롯을 덮지 않았다. 'use ${r.slot}' 로 live 를 슬롯에 맞춰라`,
	}[r.status];
	// --quiet: 실제로 바뀐 것(또는 사람이 손대야 하는 것)만 말한다. 세션마다 "변경 없음" 을
	// 찍으면 사람이 그 줄을 읽지 않게 되고, 진짜 mismatch 도 같이 안 읽힌다.
	const noisy = ["updated", "mismatch", "stale"].includes(r.status);
	if (!argv.includes("--quiet") || noisy) console.log(msg());
	if (r.status === "mismatch") process.exit(1);
}

function cmdUse(argv) {
	const slot = argv[0];
	if (!slot) die("슬롯 이름이 필요하다");
	if (!existsSync(slotPath(slot))) die(`그런 슬롯 없음: ${slot} (list 로 확인)`);
	requireFileStore();
	lockAcquire();
	const meta = loadMeta();
	const cur = meta.currentSlot;
	// 이미 그 슬롯이면 live 를 건드리지 않는다. 낡은 스냅샷으로 덮으면 회전된 live 토큰이
	// 죽는다 — 슬롯을 영구히 죽이던 바로 그 경로다. 대신 스냅샷을 최신으로 끌어올린다.
	// 이 경로는 마운트가 없어 가드 이전에 처리한다 — 그냥 sync 라서 막을 이유가 없다.
	if (cur === slot) {
		const r = syncBack();
		console.log(r.status === "updated"
			? `이미 ${slot} — 회전된 토큰을 슬롯에 반영했다 (live 는 그대로)`
			: `이미 ${slot} 이다 (변경 없음)`);
		return;
	}
	guardSwitch(argv.includes("--force"), existsSync(LIVE) ? readJson(LIVE) : null);
	if (cur) {
		const r = syncBack();
		if (r.status === "updated") console.log(`  (나가는 슬롯 ${cur} 갱신됨 — 토큰이 회전했다)`);
		if (r.status === "mismatch") console.error(`  경고: live 가 ${cur} 와 다른 계정이다 (${r.live}). 나가는 슬롯을 갱신하지 못했다`);
		if (r.status === "stale") console.error(`  참고: live 가 ${cur} 슬롯보다 낡아 되돌려 쓰지 않았다 — 슬롯 쪽이 최신이다`);
	} else {
		const guess = identifyLive();
		if (guess.length === 1) {
			currentSlotSet(guess[0]);
			const r = syncBack();
			console.log(`  (현재 슬롯 기록이 없어 account_id 로 ${guess[0]} 를 찾아 ${r.status === "updated" ? "갱신했다" : "확인했다"})`);
		} else if (existsSync(LIVE)) {
			console.error("  경고: live 가 어느 슬롯인지 모른다 — 회전된 토큰이 있었다면 그 계정은 유실된다");
		}
	}
	mount(slot);
	console.log(`전환: ${cur ?? "none"} → ${slot}  ${emailOf(readJson(slotPath(slot)))}`);
	console.log("  실행 중이던 codex 세션에는 반영되지 않는다 — 재시작해야 새 계정으로 붙는다.");
}

function cmdAdd(argv) {
	const slot = argv[0];
	if (!slot) die("슬롯 이름이 필요하다 (이메일 앞부분을 권장)");
	// 이름 검사는 로그인 **전에** 한다. 로그인을 다 끝내고 이름에서 죽으면
	// 받아온 토큰을 저장하지 못하고 버린다 — 기기 인증을 처음부터 다시 해야 한다.
	if (!SLOT_RE.test(slot)) {
		die(`슬롯 이름이 규칙에 안 맞는다: "${slot}"\n` +
			"  1~64자, 영문·숫자·'.'·'_'·'-' 만, 첫 글자는 영문 또는 숫자.\n" +
			"  이메일 전체를 주는 게 가장 흔한 실패다 ('@' 가 걸린다) — 앞부분만 써라.");
	}
	requireFileStore();
	initDir();
	if (existsSync(slotPath(slot)) && !argv.includes("--force")) die(`이미 있는 슬롯이다: ${slot} (덮어쓰려면 --force)`);
	const tmp = join(DIR, `.login-${process.pid}-${Date.now()}`);
	mkdirSync(tmp, { recursive: true, mode: 0o700 });
	// 임시 CODEX_HOME 에서 로그인한다 — 지금 쓰는 계정의 live auth.json 을 건드리지 않는다.
	// config 를 같이 넣어야 결과가 키체인이 아니라 이 디렉토리의 auth.json 으로 떨어진다.
	writeFileSync(join(tmp, "config.toml"), 'cli_auth_credentials_store = "file"\n');
	console.log("브라우저에 다른 계정이 남아 있으면 같은 계정이 중복 등록된다 — 시크릿 창을 쓰거나 먼저 로그아웃하라.\n");
	const r = spawnSync("codex", ["login", "--device-auth"], { stdio: "inherit", cwd: tmp, env: { ...process.env, CODEX_HOME: tmp } });
	const got = join(tmp, "auth.json");
	if (r.status !== 0 || !existsSync(got)) {
		rmSync(tmp, { recursive: true, force: true });
		die("로그인이 완료되지 않았다 (auth.json 이 안 생겼다). 다시 시도하라");
	}
	const auth = readJson(got);
	const dup = listSlots().filter((s) => s !== slot && accountOf(readJson(slotPath(s))) === accountOf(auth));
	copyFileSync(got, slotPath(slot));
	chmodSync(slotPath(slot), 0o600);
	rmSync(tmp, { recursive: true, force: true });
	const meta = loadMeta();
	touchSlot(meta, slot, {});
	saveMeta(meta);
	forgetDead(slot);   // 살아났으니 launch 배너에서 뺀다 (다음 sweep 을 기다리지 않는다)
	console.log(`\n추가: ${slot}  ${emailOf(auth)}`);
	if (dup.length) console.log(`  주의: 같은 계정이 이미 ${dup.join(", ")} 에 있다 (브라우저 세션이 안 바뀐 듯)`);
	console.log(`  쓰려면: use ${slot}`);
}

// ── lane: 세션별 격리 홈 만들기·반납 ────────────────────────────────────
// `~/.codex` 의 항목을 전부 심링크하고 auth.json 만 실파일로 둔다. 그래서 hooks·MCP·
// sessions·config 는 원본 그대로 쓰이고 (resume 목록도 공유된다) 계정만 갈린다.
function laneCreate(pid, seedSlot) {
	// 레인은 "지금 쓰는 홈" 의 복제다. 이미 레인 안이면 그 레인이 아니라 원본을 복제한다 —
	// 레인의 레인을 만들면 심링크가 두 겹이 되고 auth 격리가 어느 층인지 알 수 없어진다.
	const base = inLane() ? (readLane().base ?? join(HOME, ".codex")) : CODEX_HOME;
	if (!existsSync(base)) die(`${base} 가 없다 — codex 를 먼저 한 번 실행하라`);
	mkdirSync(LANES, { recursive: true, mode: 0o700 });
	const dir = join(LANES, String(pid));
	rmSync(dir, { recursive: true, force: true });
	mkdirSync(dir, { mode: 0o700 });
	for (const f of readdirSync(base)) {
		if (f === "auth.json" || f === "lane.json") continue;   // 하나는 격리, 하나는 레인 표식
		try { symlinkSync(join(base, f), join(dir, f)); } catch {}
	}
	const seed = seedSlot ? slotPath(seedSlot) : join(base, "auth.json");
	if (!existsSync(seed)) die(`씨앗 auth 가 없다: ${seed}`);
	copyFileSync(seed, join(dir, "auth.json"));
	chmodSync(join(dir, "auth.json"), 0o600);
	// 씨앗이 어느 슬롯인지 모르면 account_id 로 되짚는다 — 모르면 write-back 대상이 없어진다.
	let slot = seedSlot;
	if (!slot) {
		const acct = accountOf(readJson(join(dir, "auth.json")));
		slot = listSlots().find((t) => { try { return accountOf(readJson(slotPath(t))) === acct; } catch { return false; } }) ?? null;
	}
	writeJson(join(dir, "lane.json"), { pid, slot, base, startedAt: new Date().toISOString() });
	return dir;
}

function cmdLane(argv) {
	const [sub, ...rest] = argv;
	const pidOf = () => {
		const v = Number(numArg(rest, "--pid", NaN));
		if (!Number.isFinite(v) || v <= 0) die("--pid <번호> 가 필요하다 (레인을 소유한 셸의 pid)");
		return v;
	};
	if (sub === "new") {
		requireFileStore();
		initDir();
		// `--pid <n>` 의 값을 슬롯 이름으로 집지 않는다 — 여기서 값을 받는 플래그는 --pid 뿐이라
		// "대시로 시작하면 그 다음 토큰까지 건너뛴다" 로 충분하다.
		const positional = [];
		for (let i = 0; i < rest.length; i++) {
			if (rest[i].startsWith("-")) { i++; continue; }
			positional.push(rest[i]);
		}
		const slot = positional[0];
		if (slot && !existsSync(slotPath(slot))) die(`그런 슬롯 없음: ${slot}`);
		console.log(laneCreate(pidOf(), slot ?? null));   // stdout 은 경로 한 줄뿐 — 호출자가 CODEX_HOME 으로 쓴다
		return;
	}
	if (sub === "release") {
		const dir = join(LANES, String(pidOf()));
		rmSync(dir, { recursive: true, force: true });
		return;
	}
	if (sub === "list" || sub === undefined) {
		const held = leaseHolders();
		const mine = inLane() ? readLane() : null;
		if (mine?.slot) console.log(`이 레인: ${mine.slot}  (pid ${mine.pid})`);
		if (!held.size) { console.log("다른 레인이 잡고 있는 슬롯 없음"); return; }
		console.log(`${"SLOT".padEnd(22)}PID`);
		for (const [slot, v] of held) console.log(slot.padEnd(22) + v.pid);
		return;
	}
	die(`알 수 없는 lane 서브커맨드: ${sub} (new|release|list)`);
}

function cmdAdopt(argv) {
	requireFileStore();
	initDir();
	if (!existsSync(LIVE)) die("live auth.json 이 없다 — 보관할 로그인 계정이 없다");
	const name = argv.find((a) => !a.startsWith("-"));
	if (name && !SLOT_RE.test(name)) {
		die(`슬롯 이름이 규칙에 안 맞는다: "${name}"\n` +
			"  1~64자, 영문·숫자·'.'·'_'·'-' 만, 첫 글자는 영문 또는 숫자.");
	}
	lockAcquire();
	const before = listSlots().length;
	const slot = adoptLive(name);
	if (!slot) {
		const auth = (() => { try { return readJson(LIVE); } catch { return null; } })();
		if (!auth || !accountOf(auth)) die("live auth.json 을 읽을 수 없거나 account_id 가 없다");
		if (name) die(`${name} 슬롯에 이미 다른 계정이 있다 — 덮으면 그 계정을 잃는다. 다른 이름을 주거나 'remove ${name}' 후 다시 하라`);
		die(`슬롯 이름을 만들 수 없다 (live 이메일: ${emailOf(auth)}) — 이름을 직접 줘라: adopt <slot>`);
	}
	const auth = readJson(slotPath(slot));
	console.log(`${listSlots().length > before ? "편입" : "갱신"}: ${slot}  ${emailOf(auth)}`);
	console.log("  live 는 그대로다 — 지금 쓰던 계정이 그대로 이어진다. 현재 슬롯 기록만 맞췄다.");
}

async function cmdQuota(argv) {
	lockAcquire();   // live 는 안 건드리지만 슬롯 파일에 write-back 은 한다
	const res = await collectQuota();
	// 수동 quota 조회도 현재 슬롯의 실제 값을 이미 받았다. 예전 양수 preflight cache를
	// 남기면 바로 뒤 dscodex가 stale 값으로 launch하므로, 현재 결과로 갱신하거나 지운다.
	const current = res.slots.find((r) => r.slot === res.currentSlot);
	if (current?.state === "ok" && (current.remainingPercent ?? 0) >= MIN_REMAINING && liveMatchesSlot(current.slot)) {
		writePf({ slot: current.slot, remainingPercent: current.remainingPercent, checkedAt: new Date().toISOString() });
	} else {
		clearPreflightCache();
	}
	if (argv.includes("--json")) { console.log(JSON.stringify(res, null, 2)); return; }
	const fmt = (iso) => iso ? new Date(iso).toLocaleString("ko-KR", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "-";
	const win = (m) => m === 10080 ? "7d" : m ? `${Math.round(m / 60)}h` : "-";
	console.log(`${"SLOT".padEnd(22)}${"남음".padStart(6)}  ${"리셋".padEnd(20)}${"창".padEnd(6)}${"플랜".padEnd(6)} 크레딧`);
	console.log("-".repeat(80));
	for (const r of res.slots.sort((a, b) => ((b.remainingPercent ?? -1) - (a.remainingPercent ?? -1)) || oldestFirst(a, b))) {
		if (r.state !== "ok") { console.log(`${r.slot.padEnd(22)}  ${r.error}`); continue; }
		console.log(r.slot.padEnd(22) + `${r.remainingPercent}%`.padStart(6) + "  " +
			fmt(r.resetsAt).padEnd(20) + win(r.windowMins).padEnd(6) + String(r.planType ?? "-").padEnd(6) + " " + String(r.credits));
	}
	// 로테이션으로 뚫리는 상황과 사람이 개입해야 하는 상황을 섞어 말하지 않는다.
	const dead = res.slots.filter((r) => r.state === "auth-dead");
	if (dead.length) {
		console.log(`\n인증이 폐기된 슬롯 ${dead.length}개 — 로테이션으로는 못 살린다. 기기 인증이 필요하다 (사람만 가능):`);
		printReauth(dead);
	}
	// 판정선은 전환 정책과 같은 하한을 쓴다 (MIN_REMAINING). 여기만 `> 0` 이면 표는 "가능",
	// next/preflight 는 "없다" 라고 말하는 어긋남이 생긴다.
	const usable = usableSlots(res.slots, MIN_REMAINING);
	const spent = res.slots.filter((r) => (r.state === "ok" || r.state === "quota") && (r.remainingPercent ?? 0) < MIN_REMAINING);
	if (!usable.length && spent.length) {
		const soonest = spent.map((r) => r.resetsAt).filter(Boolean).sort()[0];
		console.log(`\n쓸 수 있는 슬롯이 없다 (남은 계정이 전부 ${MIN_REMAINING}% 미만). 가장 빠른 리셋: ${fmt(soonest)}`);
	}
	// 조회 실패는 소진과 다른 사실이다 — 뭉치면 멀쩡한 계정을 없는 것으로 세게 된다.
	const unread = unreadSlots(res.slots);
	if (!usable.length && unread.length) {
		console.log(`\n쿼터를 못 읽은 슬롯 ${unread.length}개는 별개다 — 'next' 가 그중 가장 오래 안 쓴 것부터 시도한다:`);
		for (const r of unread) console.log(`  ${r.slot.padEnd(22)} ${r.error} · 마지막 사용 ${fmtLastUsed(r.lastUsedAt)}`);
	}
	// 조회가 토큰을 회전시켜 live 까지 손댔으면 조용히 넘어가지 않는다 — 파일을 고친 건 고친 거다.
	const fixed = res.slots.filter((r) => r.repaired).map((r) => r.slot);
	if (fixed.length) console.log(`\n(조회 중 토큰이 회전해 슬롯과 live 를 함께 갱신했다: ${fixed.join(", ")})`);
	console.log(`\n현재 슬롯: ${res.currentSlot ?? "(없음)"}`);
}

// ── 사용량 (account/usage/read) ─────────────────────────────────────────
// 쿼터가 "지금 얼마 남았나" 라면 이건 "그동안 얼마나 썼나" 다. 응답은 계정 단위이고
// 일자별 토큰 버킷(쓴 날만 sparse 하게)·누적·피크·연속일을 준다. 쿼터와 마찬가지로
// 인증만 있으면 되고 **모델 쿼터를 소모하지 않는다.**
const TOKEN_UNITS = [[1e9, "B"], [1e6, "M"], [1e3, "k"]];
function fmtTokens(n) {
	if (n === null || n === undefined) return "-";
	for (const [div, suf] of TOKEN_UNITS) if (n >= div) return `${(n / div).toFixed(1)}${suf}`;
	return String(n);
}

// 버킷 날짜는 "YYYY-MM-DD" 라 문자열 비교로 정렬·필터가 된다 (로컬 타임존 기준 날짜).
const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

async function collectUsage(days) {
	const cutoff = ymd(new Date(Date.now() - (days - 1) * 86400_000));
	const rows = [];
	for (const slot of listSlots()) {
		let auth;
		try { auth = readJson(slotPath(slot)); } catch { rows.push({ slot, state: "corrupt", error: STATE_LABEL.corrupt }); continue; }
		const { result, err, rpcError, skip, repaired } = await askAsSlot(slot, auth, "account/usage/read");
		if (skip) { rows.push({ slot, email: emailOf(auth), state: "skipped", error: `건너뜀 (${skip})`, detail: skip }); continue; }
		if (!result) {
			const detail = [rpcError, err].filter(Boolean).join(" | ");
			const state = failureState(detail);
			rows.push({ slot, email: emailOf(auth), state, detail, error: `${STATE_LABEL[state]}${detail ? ` (${shortReason(detail)})` : ""}` });
			continue;
		}
		const buckets = (result.dailyUsageBuckets ?? []).slice().sort((a, b) => a.startDate.localeCompare(b.startDate));
		const recent = buckets.filter((b) => b.startDate >= cutoff);
		const peak = buckets.reduce((a, b) => (!a || b.tokens > a.tokens ? b : a), null);
		rows.push({
			slot, email: emailOf(auth), state: "ok",
			recentTokens: recent.reduce((s, b) => s + (b.tokens ?? 0), 0),
			recentDays: recent.length,
			lastActive: buckets.length ? buckets[buckets.length - 1].startDate : null,
			peakTokens: peak?.tokens ?? null,
			peakDate: peak?.startDate ?? null,
			lifetimeTokens: result.summary?.lifetimeTokens ?? null,
			longestTurnSec: result.summary?.longestRunningTurnSec ?? null,
			buckets, repaired: repaired || undefined,
		});
	}
	return { currentSlot: currentSlotGet(), days, cutoff, slots: rows };
}

async function cmdUsage(argv) {
	const di = argv.indexOf("--days");
	const days = di === -1 ? 7 : Number(argv[di + 1]);
	if (!Number.isInteger(days) || days < 1) die("--days 는 1 이상의 정수여야 한다 (기본 7)");
	lockAcquire();   // live 는 안 건드리지만 슬롯 파일에 write-back 은 한다
	const res = await collectUsage(days);
	if (argv.includes("--json")) { console.log(JSON.stringify(res, null, 2)); return; }
	console.log(`${"SLOT".padEnd(22)}${`최근${days}일`.padStart(9)}${"일수".padStart(5)}  ${"마지막".padEnd(12)}${"피크".padStart(8)} ${"(일자)".padEnd(12)}${"누적".padStart(8)}`);
	console.log("-".repeat(82));
	for (const r of res.slots.sort((a, b) => (b.recentTokens ?? -1) - (a.recentTokens ?? -1))) {
		if (r.state !== "ok") { console.log(`${r.slot.padEnd(22)}  ${r.error}`); continue; }
		console.log(r.slot.padEnd(22) + fmtTokens(r.recentTokens).padStart(9) + String(r.recentDays).padStart(5) + "  " +
			String(r.lastActive ?? "-").padEnd(12) + fmtTokens(r.peakTokens).padStart(8) + ` (${r.peakDate ?? "-"})`.padEnd(13) +
			fmtTokens(r.lifetimeTokens).padStart(8));
	}
	// 이 표의 가장 쓸모 있는 용법: **내가 안 쓴 날에 토큰이 찍힌 슬롯**을 찾는 것이다.
	// 그 계정은 다른 머신·다른 사람이 같이 쓰고 있다는 뜻이고, 그게 슬롯이 죽는 경로다.
	console.log("\n일자별 원문은 --json 의 buckets. 내가 안 쓴 날에 토큰이 찍혀 있으면 그 계정은 다른 데서도 돌고 있다.");
	const fixed = res.slots.filter((r) => r.repaired).map((r) => r.slot);
	if (fixed.length) console.log(`(조회 중 토큰이 회전해 슬롯과 live 를 함께 갱신했다: ${fixed.join(", ")})`);
	console.log(`현재 슬롯: ${res.currentSlot ?? "(없음)"}`);
}

async function cmdNext(argv) {
	const min = Math.max(MIN_REMAINING, numArg(argv, "--min", MIN_REMAINING));
	const excludeCurrent = argv.includes("--exclude-current");
	requireFileStore();
	guardSwitch(argv.includes("--force"), existsSync(LIVE) ? readJson(LIVE) : null);
	lockAcquire();
	const res = await collectQuota();
	// 라운드로빈으로 다음 칸을 밟지 마라 — 소진 계정을 먼저 골라 codex 기동을 헛돈다.
	const pool = excludeCurrent ? res.slots.filter((r) => r.slot !== res.currentSlot) : res.slots;
	const usable = usableSlots(pool, min);
	// 잔량을 읽을 수 있는 슬롯이 전부 소진됐을 때만 "모르는" 슬롯으로 내려간다.
	const unread = usable.length ? [] : unreadSlots(pool);
	if (!usable.length && !unread.length) {
		// 못 쓰는 이유를 뭉개지 마라. "기다리면 풀리는 것" 과 "사람이 재로그인해야 하는 것" 은
		// 다음 행동이 완전히 다르다 — 뭉치면 에이전트가 무한히 재시도하거나 그냥 멈춘다.
		const dead = res.slots.filter((r) => r.state === "auth-dead");
		const spent = res.slots.filter((r) => (r.state === "ok" || r.state === "quota" || r.state === "spend-limit"));
		const other = res.slots.filter((r) => !["ok", "quota", "spend-limit", "auth-dead"].includes(r.state));
		console.error(`쓸 수 있는 슬롯이 없다 (하한 ${min}%).`);
		if (spent.length) {
			console.error("  쿼터 소진 — 리셋까지 기다리는 수밖에 없다:");
			for (const r of spent) console.error(`    ${r.slot.padEnd(22)} ${r.remainingPercent ?? 0}% · 리셋 ${r.resetsAt ?? "?"}`);
		}
		if (dead.length) {
			console.error("  인증 폐기 — 기기 인증은 사람만 할 수 있다. 사용자에게 요청하라:");
			printReauth(dead, (m) => console.error(m));
		}
		for (const r of other) console.error(`    ${r.slot.padEnd(22)} ${r.error}`);
		process.exit(1);
	}
	if (!usable.length) {
		console.log(`잔량이 남은 슬롯이 없다 — 쿼터를 못 읽은 ${unread.length}개 중 가장 오래 안 쓴 것부터 시도한다:`);
		for (const r of unread) console.log(`    ${r.slot.padEnd(22)} ${r.error} · 마지막 사용 ${fmtLastUsed(r.lastUsedAt)}`);
	}
	const best = usable[0] ?? unread[0];
	// 지금 슬롯이 이미 최선과 같으면 바꾸지 않는다. 의미 없는 전환도 토큰을 회전시킨다.
	const cur = res.slots.find((r) => r.slot === res.currentSlot);
	if (usable.length && !excludeCurrent && cur && cur.state === "ok" && (cur.remainingPercent ?? 0) >= best.remainingPercent) {
		console.log(`이미 ${cur.slot} 이 최선이다 (${cur.remainingPercent}%)`);
		return;
	}
	// 같은 슬롯을 다시 마운트하면 낡은 스냅샷이 회전된 live 토큰을 덮는다 ('use' 가 막는 것과 같은 경로).
	if (best.slot === res.currentSlot) {
		console.log(`이미 ${best.slot} 이다 — 다른 슬롯이 더 낫지 않다`);
		return;
	}
	const r = syncBack();   // 나가는 슬롯의 회전된 토큰부터 되돌려 쓴다
	if (r.status === "mismatch") console.error(`  경고: live 가 ${r.slot} 와 다른 계정이다 (${r.live}) — 나가는 슬롯을 갱신하지 못했다`);
	if (r.status === "stale") console.error(`  참고: live 가 ${r.slot} 슬롯보다 낡아 되돌려 쓰지 않았다`);
	mount(best.slot);
	console.log(`전환: ${res.currentSlot ?? "none"} → ${best.slot} (${pctLabel(best)})`);
	console.log("  실행 중이던 codex 세션에는 반영되지 않는다 — 재시작해야 새 계정으로 붙는다.");
}

// ── preflight: 세션을 띄우기 직전의 자동 전환 ───────────────────────────
// dscodex.sh 가 codex 를 띄우기 전에 부른다. 하는 일은 하나 — 지금 마운트된 계정으로
// **대화가 되는지** 보고, 쿼터가 바닥이면 남은 슬롯으로 갈아끼운다.
//
// 세 가지를 지킨다. 셋 다 실제로 사고가 나서 생긴 규칙이다.
//  (1) **launch 를 막지 않는다.** 무슨 일이 있어도 exit 0. 계정을 골라 주는 편의가
//      codex 를 못 띄우게 만드는 것보다 나쁘다. 그래서 여기선 die 를 안 쓴다.
//  (2) **인증 오류에는 로테이션하지 않는다.** 옛 omx hotswap 이 인증 실패를 "이 계정 못 쓴다"로
//      읽고 슬롯을 줄줄이 밟아, 로그인 화면조차 못 보게 만들었다. 도는 건 쿼터일 때뿐이다.
//  (3) **평소엔 조회 1회.** 전 슬롯 sweep 은 현재 슬롯이 실제로 소진됐을 때만 한다.
//      그마저도 TTL 안이면 캐시로 건너뛴다 — 매 launch 마다 토큰을 건드릴 이유가 없다.
const PF_TTL = 600;                                  // 초. 캐시 유효기간
const PF_CACHE = join(DIR, "preflight.state");       // .json 이면 listSlots 가 슬롯으로 센다
const readPf = () => { try { return readJson(PF_CACHE); } catch { return null; } };
const writePf = (o) => { try { writeJson(PF_CACHE, o); } catch {} };
const clearPreflightCache = () => { try { rmSync(PF_CACHE, { force: true }); } catch {} };

// dscodex 를 칠 때마다 보이는 유일한 자리다. 죽은 슬롯은 여기서 말하지 않으면
// "쿼터가 없네" 로 오해된 채 몇 주씩 방치된다 — 실측으로 4개가 이틀을 그렇게 있었다.
// 네트워크를 쓰지 않는다: 마지막 sweep 이 적어 둔 것을 읽을 뿐이다.
function deadBanner() {
	const h = readHealth();
	const dead = (h?.dead ?? []).filter((d) => existsSync(slotPath(d.slot)));
	if (!dead.length) return;
	const log = (m) => console.error(m);
	log(`preflight: 인증이 폐기된 슬롯 ${dead.length}개 (${fmtLastUsed(h.checkedAt)} 확인) — 로테이션으로는 못 살린다. 기기 인증은 사람만 할 수 있다:`);
	printReauth(dead, log);
	log(`  계정별 잔량 전체: ${AUTH_CMD} quota`);
}

async function cmdPreflight(argv) {
	const min = Math.max(MIN_REMAINING, numArg(argv, "--min", MIN_REMAINING));
	const ttl = numArg(argv, "--ttl", PF_TTL);
	const say = (m) => console.error(`preflight: ${m}`);

	deadBanner();
	const store = credStore();
	if (!(store === "file" || (store === null && platform() !== "darwin"))) {
		say(`자격증명 저장소가 ${store ?? "미설정"} 이라 슬롯 전환이 무시된다 — 'check' 를 보라. 그대로 띄운다`);
		return;
	}
	let cur = currentSlotGet();
	if (!cur) {
		const guess = identifyLive();
		if (guess.length === 1) { currentSlotSet(cur = guess[0]); say(`현재 슬롯 기록이 없어 account_id 로 ${cur} 를 찾았다`); }
	}
	if (!cur || !existsSync(slotPath(cur))) { say("현재 슬롯을 모른다 — 'list' 로 확인하고 'use <slot>' 로 맞춰라. 그대로 띄운다"); return; }

	// 다른 레인이 이 슬롯을 쓰고 있으면 쿼터가 남았어도 비켜야 한다. 두 세션이 같은 계정의
	// refresh token 을 각각 회전시키면 재사용 탐지가 그 계정을 통째로 폐기한다.
	const heldBy = leaseHolders().get(cur);
	const cache = readPf();
	const age = cache ? (Date.now() - Date.parse(cache.checkedAt)) / 1000 : Infinity;
	if (!heldBy && !argv.includes("--force") && cache && cache.slot === cur && cache.remainingPercent >= min && age < ttl) {
		say(`${cur} ${cache.remainingPercent}% (${Math.round(age / 60)}분 전 확인)`);
		return;
	}
	if (!lockAcquire(true)) { say("다른 codex-auth 가 실행 중이라 건너뛴다"); return; }

	// 직전 세션이 회전시킨 토큰부터 슬롯에 되돌려 쓴다. 안 하면 슬롯이 이미 소비된 refresh
	// token 을 든 채 남고, 바로 아래 조회가 그 옛 토큰으로 나가 계정을 죽인다.
	const sb = syncBack();
	if (sb.status === "updated") say(`${cur}: 직전 세션이 회전시킨 토큰을 슬롯에 반영했다`);
	if (sb.status === "stale") { mount(cur); say(`live 가 ${cur} 슬롯보다 낡아 슬롯으로 맞췄다 (live ${sb.srcAt} < slot ${sb.storedAt})`); }
	if (sb.status === "mismatch") {
		const guess = identifyLive();
		if (guess.length === 1) { currentSlotSet(cur = guess[0]); say(`live 가 기록과 다른 계정이었다 — 현재 슬롯을 ${cur} 로 맞췄다`); }
		else {
			// live 가 **어느 슬롯도 아니다** — 슬롯 밖에서 `codex login` 을 하면 이렇게 된다.
			// 예전엔 여기서 return 했고, 그래서 100% 슬롯이 여섯 개 남아 있어도 dscodex 가
			// 영영 계정을 안 바꿨다 (실측 2026-08-28: 이게 "dscodex 쳐도 안 바뀐다" 의 정체다).
			// 손대지 않은 이유는 그 토큰의 사본이 없어서였다 — 그러면 사본을 만들고 계속하면 된다.
			const adopted = adoptLive();
			if (!adopted) { say(`live 가 ${cur} 와 다른 계정인데 슬롯으로 보관하지 못했다 (${sb.live}) — 손대지 않는다. 'adopt <slot>' 으로 이름을 직접 줘라`); return; }
			cur = adopted;
			say(`live 가 슬롯에 없는 계정이었다 — ${cur} 슬롯으로 보관하고 계속한다 (토큰을 잃지 않는다)`);
		}
	}

	const row = heldBy ? null : await quotaRow(cur);
	if (row?.state === "auth-dead") {
		// ⛔ 여기서 다른 슬롯으로 도는 것이 옛 hotswap 의 사고다. 인증은 사람이 고친다.
		say(`${cur} 인증이 폐기됐다 (${shortReason(row.detail ?? row.error)}). 전환하지 않는다 — 쿼터가 아니라 인증이다.`);
		console.error(`  먼저: ${AUTH_CMD} sync   (여기서 'use ${cur}' 를 시키면 그대로 따른다)`);
		console.error("  그래도 안 되면 기기 인증 (사람만 가능):");
		printReauth([{ slot: cur, email: row.email }], (m) => console.error(m));
		return;
	}
	if (row && row.state !== "ok" && row.state !== "quota") { say(`${cur} 쿼터를 못 읽었다 — ${row.error}. 그대로 띄운다`); return; }
	const remaining = row?.remainingPercent ?? 0;
	if (row && row.state === "ok" && remaining >= min) {
		writePf({ slot: cur, remainingPercent: remaining, checkedAt: new Date().toISOString() });
		say(`${cur} ${remaining}% 남음`);
		return;
	}

	say(heldBy
		? `${cur} 은 다른 세션(pid ${heldBy.pid})이 쓰고 있다 — 다른 슬롯을 찾는다 (${listSlots().length}개 조회)`
		: `${cur} ${remaining}% — 남은 슬롯을 찾는다 (${listSlots().length}개 조회)`);
	const res = await collectQuota();
	const usable = usableSlots(res.slots, min);
	// 잔량을 읽을 수 있는 슬롯이 전부 소진됐으면, 조회에 실패한 슬롯을 버리지 말고
	// 가장 오래 안 쓴 것부터 시도한다. 여기서 멈추면 멀쩡한 계정을 놔두고 0% 로 띄운다.
	const unread = usable.length ? [] : unreadSlots(res.slots).filter((r) => r.slot !== cur);
	if (!usable.length && !unread.length) {
		// 기다리면 풀리는 것과 사람이 재로그인해야 하는 것을 뭉치지 않는다 — 다음 행동이 다르다.
		const spent = res.slots.filter((r) => ["ok", "quota", "spend-limit"].includes(r.state));
		const soonest = spent.map((r) => r.resetsAt).filter(Boolean).sort()[0];
		const held = leaseHolders();
		say(`쓸 수 있는 슬롯이 없다 (전부 ${min}% 미만${held.size ? ` · 다른 세션이 ${held.size}개 대여 중` : ""}). 가장 빠른 리셋: ${soonest ? new Date(soonest).toLocaleString("ko-KR") : "?"}`);
		if (heldBy) say(`  ⚠ ${cur} 을 pid ${heldBy.pid} 와 같이 쓰게 된다 — 그 세션이 끝나면 'sync' 하라`);
		const dead = res.slots.filter((r) => r.state === "auth-dead");
		if (dead.length) say(`  인증 폐기 ${dead.length}개 — 기기 인증 필요: ${dead.map((r) => `add ${r.slot}`).join(", ")}`);
		return;
	}
	const best = usable[0] ?? unread[0];
	if (!usable.length) say(`잔량이 남은 슬롯이 없다 — 쿼터를 못 읽은 ${unread.length}개 중 가장 오래 안 쓴 ${best.slot} 을 시도한다 (마지막 사용 ${fmtLastUsed(best.lastUsedAt)})`);
	if (best.slot === cur) { say(`${cur} 이 그나마 최선이다 (${pctLabel(best)})`); return; }
	const block = switchBlocker(existsSync(LIVE) ? readJson(LIVE) : null);
	if (block) { say(`전환을 미룬다 — ${block.msg}. (${best.slot} 이 ${pctLabel(best)} 로 비어 있다)`); return; }
	const r = syncBack();
	if (r.status === "mismatch") say(`  경고: live 가 ${r.slot} 와 다른 계정이다 (${r.live}) — 나가는 슬롯을 갱신하지 못했다`);
	mount(best.slot);
	// 추측으로 고른 슬롯은 캐시하지 않는다 — 다음 launch 가 실제 잔량을 다시 확인해야 한다.
	if (usable.length) writePf({ slot: best.slot, remainingPercent: best.remainingPercent, checkedAt: new Date().toISOString() });
	else clearPreflightCache();
	say(`전환: ${cur}${heldBy ? " (대여 중)" : ` (${remaining}%)`} → ${best.slot} (${pctLabel(best)})  ${best.email}`);
}

function cmdRemove(argv) {
	const slot = argv[0];
	if (!slot) die("슬롯 이름이 필요하다");
	if (!existsSync(slotPath(slot))) die(`그런 슬롯 없음: ${slot}`);
	const meta = loadMeta();
	if (currentSlotGet() === slot) console.error("  주의: 지금 live 에 붙어있는 계정이다. live 인증은 그대로 두므로 계속 쓸 수 있지만 스냅샷은 사라진다.");
	rmSync(slotPath(slot));
	forgetDead(slot);
	meta.slots = meta.slots.filter((r) => r.slot !== slot);
	if (meta.currentSlot === slot) meta.currentSlot = null;   // 전역 기록만 — 레인은 자기 lane.json 을 쓴다
	saveMeta(meta);
	console.log(`삭제: ${slot} (live 인증과 ChatGPT 쪽 세션은 건드리지 않았다)`);
}

const [cmd, ...rest] = process.argv.slice(2);
switch (cmd ?? "list") {
	case "list": cmdList(rest); break;
	case "current": cmdCurrent(); break;
	case "check": cmdCheck(); break;
	case "sync": cmdSync(rest); break;
	case "use": cmdUse(rest); break;
	case "add": cmdAdd(rest); break;
	case "adopt": cmdAdopt(rest); break;
	case "lane": cmdLane(rest); break;
	case "quota": await cmdQuota(rest); break;
	case "usage": await cmdUsage(rest); break;
	case "next": await cmdNext(rest); break;
	case "preflight": await cmdPreflight(rest); break;
	case "remove": cmdRemove(rest); break;
	default:
		console.log(readFileSync(new URL(import.meta.url)).toString().split("\n").slice(1, 13).join("\n").replace(/^\/\/ ?/gm, ""));
		process.exit(1);
}
