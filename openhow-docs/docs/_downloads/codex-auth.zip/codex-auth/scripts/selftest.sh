#!/usr/bin/env bash
# codex-auth 샌드박스 테스트 — 진짜 ~/.codex 나 ~/.omx/auth 를 건드리지 않는다.
set -uo pipefail
S="$(cd "$(dirname "$0")" && pwd)/codex-auth.mjs"
BASE="${TMPDIR:-/tmp}/codex-auth-selftest.$$"
rm -rf "$BASE"; mkdir -p "$BASE/home" "$BASE/slots"
export CODEX_HOME="$BASE/home" CODEX_AUTH_DIR="$BASE/slots" CODEX_LANES_DIR="$BASE/lanes"
pass=0; fail=0; skipped=0
# 전환 가드 테스트는 ps 출력을 주입해 돌린다 (CODEX_AUTH_PS_FIXTURE) — 앰비언트 codex 에 안 흔들린다.
ok()   { pass=$((pass+1)); printf '  \033[32mPASS\033[0m %s\n' "$1"; }
no()   { fail=$((fail+1)); printf '  \033[31mFAIL\033[0m %s\n    %s\n' "$1" "${2:-}"; }
check(){ if eval "$2"; then ok "$1"; else no "$1" "조건 실패: $2"; fi; }
sk()   { skipped=$((skipped+1)); printf '  \033[33mSKIP\033[0m %s\n    %s\n' "$1" "${2:-}"; }
# 대화형 재시작 경로는 PTY 가 있어야 검증된다 (dscodex 가 -t 0/-t 1 로 갈라진다).
# macOS `script` 는 소켓 stdin 을 가진 셸(에이전트·일부 CI)에서 tcgetattr 로 죽는다.
# 그때는 python 의 pty 로 대체한다 — 안 그러면 이 경로가 통째로 안 돌고, 못 돌린 것이
# 통과처럼 보인다. 둘 다 없을 때만 skip 으로 센다 (초록보다 나쁜 빨강은 만들지 않는다).
have_pty=0
PTY_PY="$BASE/ptyrun.py"
cat > "$PTY_PY" <<'PYEOF'
import os, pty, sys
out = open(sys.argv[1], "wb")
def rd(fd):
    d = os.read(fd, 1024)
    out.write(d); out.flush()
    return d
sys.exit(os.waitstatus_to_exitcode(pty.spawn(sys.argv[2:], rd)))
PYEOF
if command -v script >/dev/null 2>&1 && /usr/bin/script -q /dev/null true >/dev/null 2>&1; then
	have_pty=1; ptyrun() { local t="$1"; shift; /usr/bin/script -qe "$t" "$@"; }
elif command -v python3 >/dev/null 2>&1 && python3 -c "import pty" >/dev/null 2>&1; then
	have_pty=1; ptyrun() { local t="$1"; shift; python3 "$PTY_PY" "$t" "$@"; }
fi

# 합성 auth.json — 실제 계정을 안 쓴다. id_token 은 email/iat 만 든 가짜 JWT.
# iatOff 로 "슬롯이 더 새롭다" 를, expOff 로 "곧 갱신된다(회전 레이스)" 를 합성한다.
mkauth() { # <account_id> <email> <refresh> <out> [iatOffSec=0] [expOffSec=86400]
  node -e '
  const [id,email,refresh,out,iatOff,expOff]=process.argv.slice(1);
  const b=(o)=>Buffer.from(JSON.stringify(o)).toString("base64url");
  const iat=Math.floor(Date.now()/1000)+Number(iatOff||0);
  const jwt=(p)=>`${b({alg:"none"})}.${b(p)}.x`;
  require("fs").writeFileSync(out, JSON.stringify({
    OPENAI_API_KEY:null, auth_mode:"chatgpt",
    tokens:{ id_token:jwt({email,iat}), access_token:jwt({exp:iat+Number(expOff||86400)}), refresh_token:refresh, account_id:id },
    last_refresh:new Date(iat*1000).toISOString(),
  },null,2)+"\n");' "$@"
}
tok() { node -e 'console.log(JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")).tokens.refresh_token)' "$1"; }

echo "── A. 빈 저장소 (배포 직후) ──"
out=$("$S" list 2>&1); check "빈 목록 안내" '[[ "$out" == *"슬롯 없음"* ]]'
"$S" check >/dev/null 2>&1; check "check 가 문제 있음을 exit 1 로 알린다" '[ $? -ne 0 ]'

echo "── B. 자격증명 저장소 게이트 ──"
mkauth acct-a a@example.com refresh-a1 "$BASE/slots/alpha.json"
out=$("$S" use alpha --force 2>&1); check "config 없으면 전환 거부" '[[ "$out" == *"자격증명 저장소가 파일이 아니다"* ]]'
printf 'cli_auth_credentials_store = "keychain"\n' > "$CODEX_HOME/config.toml"
out=$("$S" use alpha --force 2>&1); check "keychain 모드도 거부" '[[ "$out" == *"키체인 모드면"* ]]'
printf 'cli_auth_credentials_store = "file"\n' > "$CODEX_HOME/config.toml"

echo "── C. 첫 슬롯 마운트 ──"
out=$("$S" use alpha --force 2>&1); check "전환 성공" '[[ "$out" == *"전환: none → alpha"* ]]'
check "live 에 복사됨" '[ "$(tok "$CODEX_HOME/auth.json")" = "refresh-a1" ]'
check "live 권한 600" '[ "$(stat -f %Lp "$CODEX_HOME/auth.json")" = "600" ]'
out=$("$S" use alpha --force 2>&1); check "같은 슬롯 재전환은 no-op" '[[ "$out" == *"이미 alpha 이다"* ]]'

echo "── D. 토큰 회전 → 나가는 슬롯 write-back (핵심) ──"
mkauth acct-a a@example.com refresh-a2 "$CODEX_HOME/auth.json"   # codex 가 갱신한 상황
mkauth acct-b b@example.com refresh-b1 "$BASE/slots/bravo.json"
out=$("$S" use bravo --force 2>&1)
check "나가는 슬롯 갱신을 보고한다" '[[ "$out" == *"나가는 슬롯 alpha 갱신됨"* ]]'
check "alpha 슬롯이 회전된 토큰을 갖는다" '[ "$(tok "$BASE/slots/alpha.json")" = "refresh-a2" ]'
check "live 는 bravo 다" '[ "$(tok "$CODEX_HOME/auth.json")" = "refresh-b1" ]'

echo "── E. 낡은 스냅샷이 회전된 live 를 덮지 않는다 ──"
mkauth acct-b b@example.com refresh-b2 "$CODEX_HOME/auth.json"   # 또 갱신됨
out=$("$S" use bravo --force 2>&1)
check "현재 슬롯 재지정은 슬롯을 끌어올린다" '[[ "$out" == *"회전된 토큰을 슬롯에 반영"* ]]'
check "live 가 안 덮였다" '[ "$(tok "$CODEX_HOME/auth.json")" = "refresh-b2" ]'
check "슬롯이 최신이다" '[ "$(tok "$BASE/slots/bravo.json")" = "refresh-b2" ]'

echo "── F. 계정 불일치면 write-back 을 거부한다 ──"
mkauth acct-zzz z@example.com refresh-z1 "$CODEX_HOME/auth.json" # live 가 남의 계정
out=$("$S" sync 2>&1); rc=$?
check "sync 가 거부하고 exit 1" '[ $rc -ne 0 ] && [[ "$out" == *"account_id 불일치"* ]]'
check "bravo 슬롯이 오염되지 않았다" '[ "$(tok "$BASE/slots/bravo.json")" = "refresh-b2" ]'
mkauth acct-b b@example.com refresh-b2 "$CODEX_HOME/auth.json"

echo "── G. 락 ──"
mkdir -p "$BASE/slots/.lock"; echo 99999999 > "$BASE/slots/.lock/pid"
out=$("$S" use alpha --force 2>&1); check "죽은 주인의 락은 회수한다" '[[ "$out" == *"전환:"* ]]'
mkdir -p "$BASE/slots/.lock"; echo $$ > "$BASE/slots/.lock/pid"
out=$("$S" use bravo --force 2>&1); rc=$?
check "살아있는 주인의 락은 거부한다" '[ $rc -ne 0 ] && [[ "$out" == *"다른 codex-auth"* ]]'
rm -rf "$BASE/slots/.lock"

echo "── H. 입력 검증 · 삭제 ──"
out=$("$S" add "some@one.com" 2>&1); check "이메일 전체는 로그인 전에 거부" '[[ "$out" == *"슬롯 이름이 규칙에 안 맞는다"* ]]'
out=$("$S" add "-dash" 2>&1);       check "첫 글자 규칙" '[[ "$out" == *"규칙에 안 맞는다"* ]]'
out=$("$S" use ghost 2>&1);         check "없는 슬롯" '[[ "$out" == *"그런 슬롯 없음"* ]]'
out=$("$S" remove alpha 2>&1);      check "삭제" '[[ "$out" == *"삭제: alpha"* ]] && [ ! -f "$BASE/slots/alpha.json" ]'
check "live 인증은 남아있다" '[ -f "$CODEX_HOME/auth.json" ]'
out=$("$S" list 2>&1);              check "목록에서 사라졌다" '[[ "$out" != *"alpha"* ]]'

# ps 가 없는 호스트(Windows 네이티브)에서는 codexProcs() 가 빈 배열을 주고 전환 가드가 조용히
# 꺼진다. 조용히 사라진 안전판이 가장 나쁘므로 check 가 그걸 말해야 한다 (WINDOWS.md).
mkdir -p "$BASE/nops"; ln -sf "$(command -v node)" "$BASE/nops/node" 2>/dev/null
out=$(env -u CODEX_AUTH_PS_FIXTURE PATH="$BASE/nops" "$(command -v node)" "$S" check 2>&1)
check "ps 가 없으면 가드가 꺼진 것을 알린다" '[[ "$out" == *"전환 가드"* ]] && [[ "$out" == *"WINDOWS.md"* ]]'
check "ps 가 있으면 그 경고를 띄우지 않는다" '[[ "$("$S" check 2>&1)" != *"전환 가드"* ]]'

echo "── I. 손상된 슬롯 파일 ──"
echo "not json" > "$BASE/slots/broken.json"
out=$("$S" list 2>&1);        check "list 가 죽지 않는다" '[[ "$out" == *"파일 손상"* ]]'
out=$("$S" list --json 2>&1); check "list --json 도 죽지 않는다" '[[ "$out" == *"파일 손상"* ]]'

echo "── J. 전환 가드 (ps 를 주입해 결정적으로 검증) ──"
mkauth acct-c c@example.com refresh-c1 "$BASE/slots/charlie.json"
fx="$BASE/ps.txt"
cat > "$fx" <<'PS'
 4242 /opt/homebrew/lib/node_modules/@openai/codex/vendor/bin/codex exec --skip-git-repo-check hello
PS
out=$(CODEX_AUTH_PS_FIXTURE="$fx" "$S" use charlie 2>&1); rc=$?
check "codex exec 배치가 돌면 거부" '[ $rc -ne 0 ] && [[ "$out" == *"codex exec 배치가 돌고 있다"* ]]'

# 이 회귀가 자동 전환을 통째로 막았다: Claude Code 의 codex 플러그인이 세션 내내
# app-server 브로커를 띄워 둔다. 그걸 "실행 중" 으로 세면 전환이 영원히 안 된다.
cat > "$fx" <<'PS'
 37134 node /Users/x/.local/bin/codex app-server
 37154 /opt/homebrew/lib/node_modules/@openai/codex/vendor/bin/codex app-server
PS
out=$(CODEX_AUTH_PS_FIXTURE="$fx" "$S" use charlie 2>&1); rc=$?
check "app-server 브로커는 전환을 막지 않는다" '[ $rc -eq 0 ] && [[ "$out" == *"전환:"* ]]'
check "그래도 돌고 있다고 알린다" '[[ "$out" == *"참고: codex"* ]]'

cat > "$fx" <<'PS'
 5555 /bin/zsh -c echo now running codex exec somewhere
PS
out=$(CODEX_AUTH_PS_FIXTURE="$fx" "$S" use bravo 2>&1); rc=$?
check "명령줄에 codex 가 든 남의 셸은 안 잡는다" '[ $rc -eq 0 ] && [[ "$out" == *"전환:"* ]]'

# 회전 레이스: 나가는 계정의 access token 이 곧 만료면 codex 가 refresh 를 돌릴 참이다.
mkauth acct-b b@example.com refresh-b2 "$CODEX_HOME/auth.json" 0 60
cat > "$fx" <<'PS'
 37134 node /Users/x/.local/bin/codex app-server
PS
out=$(CODEX_AUTH_PS_FIXTURE="$fx" "$S" use charlie 2>&1); rc=$?
check "토큰 회전 레이스면 거부" '[ $rc -ne 0 ] && [[ "$out" == *"토큰 갱신이"* ]]'
out=$(CODEX_AUTH_PS_FIXTURE="$fx" "$S" use charlie --force 2>&1)
check "--force 는 경고와 함께 진행" '[[ "$out" == *"--force 로 진행한다"* ]] && [[ "$out" == *"전환:"* ]]'

echo "── K. 슬롯이 live 보다 새로우면 되돌려 쓰지 않는다 ──"
# quota 조회가 슬롯만 갱신한 상황. 여기서 낡은 live 로 슬롯을 덮으면 이미 소비된
# refresh token 이 부활해 다음 마운트에서 계정이 죽는다.
mkauth acct-c c@example.com refresh-c9 "$BASE/slots/charlie.json" 3600
out=$("$S" sync 2>&1)
check "낡은 live 로 새 슬롯을 덮지 않는다" '[[ "$out" == *"live 가 슬롯보다 낡았다"* ]]'
check "슬롯이 그대로다" '[ "$(tok "$BASE/slots/charlie.json")" = "refresh-c9" ]'

echo "── L. usage 인자 검증 ──"
# codex 를 띄우기 **전에** 죽는 경로만 건다 — 실제 조회는 네트워크·살아있는 계정이 필요해
# 샌드박스에서 못 돌린다 (그건 실환경에서 확인한다).
out=$("$S" usage --days 0 2>&1);   check "--days 0 거부" '[[ "$out" == *"1 이상의 정수"* ]]'
out=$("$S" usage --days abc 2>&1); check "--days 비정수 거부" '[[ "$out" == *"1 이상의 정수"* ]]'

echo "── M. preflight (dscodex 가 부르는 자동 전환) ──"
# 쿼터 조회는 네트워크·살아있는 계정이 필요하다 → CODEX_AUTH_QUOTA_FIXTURE 로 응답을 주입해
# **판정과 전환**만 결정적으로 건다. ps 도 빈 파일로 고정해 앰비언트 codex 에 안 흔들린다.
export CODEX_AUTH_DIR="$BASE/slots2"; mkdir -p "$CODEX_AUTH_DIR"
: > "$BASE/ps-empty.txt"
export CODEX_AUTH_PS_FIXTURE="$BASE/ps-empty.txt"
export CODEX_AUTH_QUOTA_FIXTURE="$BASE/quota.json"
qf() { printf '%s' "$1" > "$BASE/quota.json"; }
mkauth acct-p p@example.com refresh-p1 "$CODEX_AUTH_DIR/primary.json"
mkauth acct-q q@example.com refresh-q1 "$CODEX_AUTH_DIR/spare.json"
mkauth acct-r r@example.com refresh-r1 "$CODEX_AUTH_DIR/thin.json"
"$S" use primary --force >/dev/null 2>&1

qf '{"primary":{"state":"ok","remainingPercent":80},"spare":{"state":"ok","remainingPercent":100},"thin":{"state":"ok","remainingPercent":3}}'
out=$("$S" preflight --force 2>&1); rc=$?
check "여유 있으면 전환하지 않는다" '[ $rc -eq 0 ] && [[ "$out" == *"primary 80% 남음"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-p1" ]'

# 메타데이터의 currentSlot만 믿고 cache하면 실제 live 계정의 불일치 복구를 건너뛴다.
mkauth acct-q q@example.com refresh-q1 "$CODEX_HOME/auth.json"
out=$("$S" quota --json 2>&1); rc=$?
check "live 계정이 다르면 quota가 양수 cache를 쓰지 않는다" '[ $rc -eq 0 ] && [ ! -f "$CODEX_AUTH_DIR/preflight.state" ]'
out=$("$S" preflight 2>&1); rc=$?
check "계정 불일치 뒤 일반 preflight가 cache 대신 live를 복구한다" '[ $rc -eq 0 ] && [[ "$out" == *"live 가 기록과 다른 계정이었다"* ]] && [[ "$out" != *"분 전 확인"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-q1" ]'
"$S" use primary --force >/dev/null 2>&1
"$S" preflight --force >/dev/null 2>&1

qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100}}'
out=$("$S" preflight 2>&1)
check "TTL 안이면 조회를 건너뛴다 (캐시)" '[[ "$out" == *"분 전 확인"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-p1" ]'

# 수동 quota도 이미 실제 현재 값을 받았으므로, 양수 cache를 유지하면 안 된다.
out=$("$S" quota --json 2>&1); rc=$?
check "quota가 소진 결과를 받으면 preflight cache를 지운다" '[ $rc -eq 0 ] && [ ! -f "$CODEX_AUTH_DIR/preflight.state" ]'

# dscodex 는 세션 종료 뒤 sync --quiet을 부른다. 세션에서 쿼터가 소진됐으면 그 시점에
# cache를 버려야 다음 일반 preflight가 현재 값을 읽고 전환한다.
qf '{"primary":{"state":"ok","remainingPercent":80},"spare":{"state":"ok","remainingPercent":100},"thin":{"state":"ok","remainingPercent":3}}'
"$S" preflight --force >/dev/null 2>&1
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100}}'
out=$("$S" sync --quiet 2>&1); rc=$?
check "세션 종료 sync가 preflight cache를 지운다" '[ $rc -eq 0 ] && [ ! -f "$CODEX_AUTH_DIR/preflight.state" ]'
out=$("$S" preflight 2>&1); rc=$?
check "cache를 지운 뒤 쿼터 소진이면 일반 preflight가 전환한다" '[ $rc -eq 0 ] && [[ "$out" == *"전환: primary"* ]] && [[ "$out" == *"spare"* ]]'
check "live 가 실제로 갈렸다" '[ "$(tok "$CODEX_HOME/auth.json")" = "refresh-q1" ]'

# 인증 오류에 로테이션하면 로그인 화면조차 못 본다 (옛 hotswap 사고). 쿼터일 때만 돈다.
qf '{"spare":{"state":"auth-dead"},"primary":{"state":"ok","remainingPercent":100}}'
out=$("$S" preflight --force 2>&1); rc=$?
check "인증 폐기면 전환하지 않는다" '[ $rc -eq 0 ] && [[ "$out" == *"인증이 폐기됐다"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-q1" ]'
check "사람이 할 일을 알려준다" '[[ "$out" == *"add spare"* ]]'

# provider가 99% 사용을 보고해도 실제로는 5시간 한도 오류를 낸다. 1%는 선택하면 안 된다.
qf '{"spare":{"state":"ok","remainingPercent":0,"resetsAt":"2026-08-21T00:52:00Z"},"primary":{"state":"quota","remainingPercent":0},"thin":{"state":"ok","remainingPercent":1}}'
out=$("$S" preflight --force --min 0 2>&1); rc=$?
check "1% 슬롯은 낮은 --min에도 전환하지 않는다" '[ $rc -eq 0 ] && [[ "$out" == *"쓸 수 있는 슬롯이 없다"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-q1" ]'

# 잔량이 0%인 슬롯은 기본 하한을 낮춰도 선택하지 않는다.
qf '{"spare":{"state":"ok","remainingPercent":0,"resetsAt":"2026-08-21T00:52:00Z"},"primary":{"state":"quota","remainingPercent":0},"thin":{"state":"ok","remainingPercent":0}}'
out=$("$S" preflight --force 2>&1); rc=$?
check "0% 슬롯은 전환 없이 알린다" '[ $rc -eq 0 ] && [[ "$out" == *"쓸 수 있는 슬롯이 없다"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-q1" ]'

# exec 배치가 돌면 전환하지 않는다 (한 레인 살리려다 아홉을 죽인다). 그래도 launch 는 막지 않는다.
"$S" use spare --force >/dev/null 2>&1
qf '{"spare":{"state":"ok","remainingPercent":0},"primary":{"state":"ok","remainingPercent":90}}'
cat > "$BASE/ps-exec.txt" <<'PS'
 4242 /opt/homebrew/lib/node_modules/@openai/codex/vendor/bin/codex exec --skip-git-repo-check hello
PS
out=$(CODEX_AUTH_PS_FIXTURE="$BASE/ps-exec.txt" "$S" preflight --force 2>&1); rc=$?
check "exec 배치 중에는 전환을 미룬다" '[ $rc -eq 0 ] && [[ "$out" == *"전환을 미룬다"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-q1" ]'

out=$("$S" list 2>&1)
check "캐시 파일이 슬롯으로 안 잡힌다" '[[ "$out" != *"preflight"* ]] && [ -f "$CODEX_AUTH_DIR/preflight.state" ]'

echo "── M2. 선택 순서 (오래 안 쓴 슬롯 먼저 · 조회 실패는 버리지 않는다) ──"
# 마지막 사용 시각을 직접 박는다 — `use` 를 순서대로 부르는 방식은 ms 차이에 의존해 흔들린다.
setlast() { node -e '
const fs = require("fs"), p = process.argv[1];
const m = JSON.parse(fs.readFileSync(p, "utf8")); m.slots ??= [];
for (let i = 2; i < process.argv.length; i += 2) {
  let row = m.slots.find((s) => s.slot === process.argv[i]);
  if (!row) { row = { slot: process.argv[i] }; m.slots.push(row); }
  row.lastUsedAt = process.argv[i + 1];
}
fs.writeFileSync(p, JSON.stringify(m, null, 2));
' "$CODEX_AUTH_DIR/slots.json" "$@"; }

# 잔량이 같으면 알파벳순이 아니라 가장 오래 안 쓴 슬롯이다 (창은 마지막 사용 시점부터 흐른다).
"$S" use primary --force >/dev/null 2>&1
setlast spare 2026-08-27T10:00:00.000Z thin 2026-08-20T10:00:00.000Z
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100},"thin":{"state":"ok","remainingPercent":100}}'
out=$("$S" next 2>&1); rc=$?
check "잔량 동률이면 가장 오래 안 쓴 슬롯" '[ $rc -eq 0 ] && [[ "$out" == *"→ thin (100%)"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-r1" ]'

# 조회 실패를 소진으로 뭉치면 멀쩡한 계정을 놔두고 "없다" 고 한다. 마지막 수단으로 시도한다.
"$S" use primary --force >/dev/null 2>&1
setlast spare 2026-08-27T10:00:00.000Z thin 2026-08-20T10:00:00.000Z
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"network"},"thin":{"state":"network"}}'
out=$("$S" next 2>&1); rc=$?
check "전부 소진이면 조회 실패 슬롯을 오래된 순으로 시도한다" '[ $rc -eq 0 ] && [[ "$out" == *"→ thin (잔량 미상)"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-r1" ]'

# 잔량이 읽히는 슬롯이 하나라도 있으면 그쪽이 먼저다 — 추측은 진짜 신호를 이기지 못한다.
"$S" use primary --force >/dev/null 2>&1
setlast spare 2026-08-27T10:00:00.000Z thin 2026-08-20T10:00:00.000Z
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":50},"thin":{"state":"network"}}'
out=$("$S" next 2>&1); rc=$?
check "읽히는 잔량이 조회 실패보다 우선한다" '[ $rc -eq 0 ] && [[ "$out" == *"→ spare (50%)"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-q1" ]'

# preflight 도 같은 사다리를 탄다. 단, 추측으로 고른 슬롯은 캐시하지 않는다.
"$S" use primary --force >/dev/null 2>&1
setlast spare 2026-08-27T10:00:00.000Z thin 2026-08-20T10:00:00.000Z
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"network"},"thin":{"state":"unknown"}}'
out=$("$S" preflight --force 2>&1); rc=$?
check "preflight 도 조회 실패 슬롯으로 내려간다" '[ $rc -eq 0 ] && [[ "$out" == *"→ thin (잔량 미상)"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-r1" ]'
check "추측으로 고른 슬롯은 캐시하지 않는다" '[ ! -f "$CODEX_AUTH_DIR/preflight.state" ]'

# 인증 폐기는 "모른다" 가 아니라 확실한 신호다. 여기로 도는 것이 옛 hotswap 사고였다.
"$S" use primary --force >/dev/null 2>&1
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"auth-dead"},"thin":{"state":"auth-dead"}}'
out=$("$S" next 2>&1); rc=$?
check "인증 폐기 슬롯은 마지막 수단에도 안 고른다" '[ $rc -ne 0 ] && [[ "$out" == *"인증 폐기"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-p1" ]'

echo "── M2b. live 가 슬롯 밖 계정일 때 (adopt · 교착 해소) ──"
# 슬롯 밖에서 codex login 을 하면 live 가 어느 슬롯도 아니게 된다. 예전 preflight 는 거기서
# return 했고, 100% 슬롯이 남아 있어도 dscodex 가 영영 계정을 안 바꿨다 (실측 2026-08-28).
"$S" use primary --force >/dev/null 2>&1
mkauth acct-z zoe99@example.com refresh-z1 "$CODEX_HOME/auth.json"
out=$("$S" adopt 2>&1); rc=$?
check "adopt 가 live 를 이메일 앞부분 슬롯으로 보관한다" '[ $rc -eq 0 ] && [[ "$out" == *"편입: zoe99"* ]] && [ "$(tok "$CODEX_AUTH_DIR/zoe99.json")" = "refresh-z1" ]'
check "adopt 는 live 를 건드리지 않는다" '[ "$(tok "$CODEX_HOME/auth.json")" = "refresh-z1" ]'
out=$("$S" current 2>&1); check "현재 슬롯 기록이 편입한 슬롯으로 맞춰진다" '[[ "$out" == *"현재 슬롯: zoe99"* ]]'
out=$("$S" adopt 2>&1); check "같은 계정을 두 번 편입해도 슬롯이 늘지 않는다" '[[ "$out" == *"갱신: zoe99"* ]]'
out=$("$S" adopt primary 2>&1); rc=$?
check "다른 계정이 쓰는 이름으로는 편입하지 않는다" '[ $rc -ne 0 ] && [[ "$out" == *"이미 다른 계정이 있다"* ]] && [ "$(tok "$CODEX_AUTH_DIR/primary.json")" = "refresh-p1" ]'
"$S" remove zoe99 >/dev/null 2>&1

# preflight 는 그 상황에서 멈추지 않는다 — 먼저 슬롯으로 보관한 뒤 평소 흐름을 탄다.
mkauth acct-z zoe99@example.com refresh-z1 "$CODEX_HOME/auth.json"
node -e '
const fs=require("fs"),p=process.argv[1];const m=JSON.parse(fs.readFileSync(p,"utf8"));
m.currentSlot="primary";fs.writeFileSync(p,JSON.stringify(m,null,2));' "$CODEX_AUTH_DIR/slots.json"
qf '{"primary":{"state":"ok","remainingPercent":0},"zoe99":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100},"thin":{"state":"ok","remainingPercent":40}}'
out=$("$S" preflight --force 2>&1); rc=$?
check "preflight 가 슬롯 밖 live 를 보관하고 계속 진행한다" '[ $rc -eq 0 ] && [[ "$out" == *"슬롯에 없는 계정이었다"* ]] && [[ "$out" == *"zoe99"* ]]'
check "보관 뒤 실제로 남은 슬롯으로 전환한다" '[[ "$out" == *"→ spare (100%)"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-q1" ]'
check "보관된 토큰이 슬롯에 살아 있다 (유실 없음)" '[ "$(tok "$CODEX_AUTH_DIR/zoe99.json")" = "refresh-z1" ]'
"$S" remove zoe99 >/dev/null 2>&1

echo "── M3. 죽은 슬롯은 launch 때마다 보인다 (조회 없이) ──"
# 인증 폐기는 로테이션으로 안 살아난다. sweep 때 적어 두고 launch 마다 읽어서 보여준다 —
# launch 앞에 전수 조회를 붙일 수는 없기 때문이다 (슬롯 11개 ≈ 13초).
mkauth acct-g g@example.com refresh-g1 "$CODEX_AUTH_DIR/ghost.json"
"$S" use primary --force >/dev/null 2>&1
qf '{"primary":{"state":"ok","remainingPercent":80},"spare":{"state":"auth-dead"},"thin":{"state":"auth-dead"},"ghost":{"state":"auth-dead"}}'
"$S" quota >/dev/null 2>&1
check "sweep 이 죽은 슬롯을 기록한다" '[ -f "$CODEX_AUTH_DIR/health.state" ] && grep -q spare "$CODEX_AUTH_DIR/health.state"'
out=$("$S" preflight 2>&1)
check "launch 배너가 죽은 슬롯을 알린다" '[[ "$out" == *"인증 폐기 3개"* ]]'
check "배너가 그대로 붙여넣을 명령을 준다" '[[ "$out" == *"add spare --force"* ]] && [[ "$out" == *"codex-auth.mjs add"* ]]'
check "배너가 로그인 방법까지 설명한다" '[[ "$out" == *"시크릿 창"* ]]'
check "배너가 조회 없이도 뜬다 (TTL 캐시 경로)" '[[ "$out" == *"분 전 확인"* ]]'
"$S" remove ghost >/dev/null 2>&1
out=$("$S" preflight 2>&1)
check "슬롯이 사라지면 배너에서 빠진다" '[[ "$out" == *"인증 폐기 2개"* ]]'
out=$("$S" list 2>&1)
# dscodex 를 칠 때마다 계정 현황을 본다. 네트워크는 안 쓴다 — 마지막 sweep 스냅샷을 읽는다.
out=$("$S" preflight --force 2>&1)
check "매 launch 에 계정 현황 표가 뜬다" '[[ "$out" == *"쓸 수 있는 것"* ]] && [[ "$out" =~ 계정\ [0-9]+개 ]]'
check "표가 계정 고르는 법을 알려준다" '[[ "$out" == *"CODEX_SLOT="* ]] && [[ "$out" == *"대여 중인 것도 쓸 수 있다"* ]]'
check "표가 현재 슬롯을 표시한다" '[[ "$out" == *"* primary"* ]]'
check "표가 대여 상태를 보여준다" '[[ "$out" == *"리셋"* ]] || [[ "$out" == *"인증 폐기"* ]]'
out=$(DSCODEX_QUOTA=0 "$S" preflight --force 2>&1)
check "DSCODEX_QUOTA=0 이면 표를 끈다" '[[ "$out" != *"쓸 수 있는 것"* ]]'

check "health.state 가 슬롯으로 안 잡힌다" '[[ "$out" != *"health"* ]]'

# 실측 사고 (2026-08-27): 폐기로 확인된 슬롯이 다음 조회에서 25초 타임아웃(state=network)을
# 내자, 마지막-수단 로직이 그 침묵을 "모른다" 로 읽고 죽은 계정을 마운트했다.
"$S" use primary --force >/dev/null 2>&1
qf '{"primary":{"state":"ok","remainingPercent":80},"spare":{"state":"auth-dead"},"thin":{"state":"auth-dead"}}'
"$S" quota >/dev/null 2>&1
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"network"},"thin":{"state":"network"}}'
out=$("$S" next 2>&1); rc=$?
check "폐기로 확인된 슬롯은 조회가 침묵해도 안 고른다" '[ $rc -ne 0 ] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-p1" ]'
dead_has() { node -e 'const h=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"));process.exit((h.dead??[]).some(d=>d.slot===process.argv[2])?0:1)' "$CODEX_AUTH_DIR/health.state" "$1"; }
check "조회 실패는 살아났다는 증거가 아니다 (기록이 남는다)" 'dead_has spare'
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":90},"thin":{"state":"network"}}'
out=$("$S" next 2>&1); rc=$?
check "살아난(ok) 슬롯은 폐기 기록에서 빠진다" '[ $rc -eq 0 ] && [[ "$out" == *"→ spare (90%)"* ]] && ! dead_has spare'

echo "── N. 5시간 창 (실제 rateLimits 응답 fixture) ──"
# 이미 정규화된 fixture만으로는 primary/secondary 파서가 5시간 창을 선택하는지 증명할 수 없다.
# 실제 app-server 응답 모양을 주입해 5시간 창이 0%면 주간 잔량과 무관하게 전환하는지 고정한다.
"$S" use primary --force >/dev/null 2>&1
qf '{
  "primary": {
    "rateLimits": {
      "primary": { "usedPercent": 99, "resetsAt": 1787994000, "windowDurationMins": 300 },
      "secondary": { "usedPercent": 10, "resetsAt": 1788570000, "windowDurationMins": 10080 }
    }
  },
  "spare": {
    "rateLimits": {
      "primary": { "usedPercent": 5, "resetsAt": 1787994000, "windowDurationMins": 300 },
      "secondary": { "usedPercent": 20, "resetsAt": 1788570000, "windowDurationMins": 10080 }
    }
  }
}'
out=$("$S" quota --json 2>&1); rc=$?
check "quota가 5시간·장기 창과 99% 경계 근거를 보존" '[ $rc -eq 0 ] && [[ "$out" == *"\"bindingWindow\": \"primary\""* ]] && [[ "$out" == *"\"windowMins\": 300"* ]] && [[ "$out" == *"\"windowMins\": 10080"* ]] && [[ "$out" == *"\"remainingPercent\": 1"* ]]'
out=$("$S" preflight 2>&1); rc=$?
check "5시간 99% 사용이면 일반 preflight가 장기 잔량과 무관하게 전환" '[ $rc -eq 0 ] && [[ "$out" == *"전환: primary (1%) → spare (80%)"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-q1" ]'
"$S" use primary --force >/dev/null 2>&1
out=$("$S" next 2>&1); rc=$?
check "next도 5시간 한도 소진 슬롯을 건너뛴다" '[ $rc -eq 0 ] && [[ "$out" == *"전환: primary → spare (80%)"* ]] && [ "$(tok "$CODEX_HOME/auth.json")" = "refresh-q1" ]'

echo "── P. 레인 (세션 격리 · 슬롯 배타 대여) ──"
# 세션이 ~/.codex/auth.json 하나를 공유하면 계정 하나가 소진될 때 전부 같이 죽는다.
# 레인은 홈을 통째로 심링크하고 auth.json 만 실파일로 둔다 — 계정만 갈리고 나머지는 공유.
"$S" use primary --force >/dev/null 2>&1
sleep 120 & holder=$!
laneA="$("$S" lane new --pid "$holder" spare)"
check "레인이 만들어진다" '[ -d "$laneA" ] && [ -f "$laneA/lane.json" ]'
check "auth.json 만 실파일이고 나머지는 심링크" '[ ! -L "$laneA/auth.json" ] && [ -L "$laneA/config.toml" ]'
check "레인 auth 는 지정한 슬롯" '[ "$(tok "$laneA/auth.json")" = "refresh-q1" ]'
check "공유 홈 auth 는 안 바뀐다 (다른 세션이 안 죽는다)" '[ "$(tok "$CODEX_HOME/auth.json")" = "refresh-p1" ]'
out=$("$S" lane list 2>&1); check "대여 현황을 보여준다" '[[ "$out" == *"spare"* ]] && [[ "$out" == *"$holder"* ]]'

# 다른 레인이 잡고 있는 슬롯은 잔량이 아무리 많아도 후보가 아니다 — 두 세션이 같은 계정의
# refresh token 을 각각 회전시키면 재사용 탐지가 그 계정을 통째로 폐기한다.
laneB="$("$S" lane new --pid $$)"
check "레인 B 씨앗은 공유 홈의 현재 계정" '[ "$(tok "$laneB/auth.json")" = "refresh-p1" ]'
# 미대여 대안이 있으면 잔량이 더 적어도 그쪽으로 간다 — 남이 쓰는 계정을 건드리지 않는다.
# (대안이 하나도 없을 때의 회수는 Q 섹션에서 따로 건다.)
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100},"thin":{"state":"ok","remainingPercent":50}}'
out=$(CODEX_HOME="$laneB" "$S" preflight --force 2>&1)
check "대여 중인 슬롯은 잔량이 더 많아도 안 고른다" '[[ "$out" == *"→ thin (50%)"* ]] && [ "$(tok "$laneB/auth.json")" = "refresh-r1" ]'

# 주인이 죽으면 대여는 자동으로 풀린다 (락 파일을 손으로 지울 일이 없어야 한다).
kill "$holder" 2>/dev/null; wait "$holder" 2>/dev/null
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100},"thin":{"state":"ok","remainingPercent":0}}'
out=$(CODEX_HOME="$laneB" "$S" preflight --force 2>&1)
check "주인이 죽으면 대여가 풀린다" '[[ "$out" == *"→ spare (100%)"* ]] && [ "$(tok "$laneB/auth.json")" = "refresh-q1" ]'
check "레인 전환이 공유 홈을 건드리지 않는다" '[ "$(tok "$CODEX_HOME/auth.json")" = "refresh-p1" ]'

# 레인 안의 "현재 슬롯" 은 전역 기록과 별개다. 안 그러면 레인 A 의 전환이 레인 B 를 오도한다.
out=$("$S" current 2>&1); check "전역 현재 슬롯은 그대로 primary" '[[ "$out" == *"현재 슬롯: primary"* ]]'
out=$(CODEX_HOME="$laneB" "$S" current 2>&1); check "레인의 현재 슬롯은 그 레인 것" '[[ "$out" == *"현재 슬롯: spare"* ]]'

"$S" lane release --pid "$holder"; "$S" lane release --pid $$
check "반납하면 레인이 사라진다" '[ ! -d "$laneA" ] && [ ! -d "$laneB" ]'

echo "── Q. 대여 회수 (작업 끝난 세션이 슬롯을 물고 있을 때) ──"
# 실측: 슬롯 8개 중 6개가 이미 끝난 세션에 물려 "쓸 수 있는 슬롯이 없다" 가 나왔다.
# 미대여 슬롯이 하나도 없을 때만, 물고만 있는 레인에서 되찾는다.
"$S" use primary --force >/dev/null 2>&1
sleep 120 & holder=$!
laneA="$("$S" lane new --pid "$holder" spare)"
laneB="$("$S" lane new --pid $$)"
printf '  %d     1\n' "$holder" > "$BASE/ppid-idle.txt"          # holder 아래 codex 없음
printf '  %d     1\n  4242  %d\n' "$holder" "$holder" > "$BASE/ppid-busy.txt"   # holder 아래 codex 있음
printf ' 4242 /opt/homebrew/bin/codex\n' > "$BASE/ps-session2.txt"
printf ' 4242 /opt/homebrew/bin/codex exec --skip-git-repo-check hi\n' > "$BASE/ps-exec2.txt"

# 다른 슬롯이 비어 있으면 남의 것을 뺏지 않는다.
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100},"thin":{"state":"ok","remainingPercent":90}}'
out=$(CODEX_AUTH_PPID_FIXTURE="$BASE/ppid-idle.txt" CODEX_HOME="$laneB" "$S" preflight --force 2>&1)
check "미대여 슬롯이 있으면 회수하지 않는다" '[[ "$out" == *"→ thin (90%)"* ]] && [[ "$out" != *"회수한다"* ]]'

# 비어 있는 슬롯이 없고, 물고 있는 레인이 codex 를 안 돌리면 → 조용히 회수한다.
"$S" use primary --force >/dev/null 2>&1
laneB="$("$S" lane new --pid $$)"
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100},"thin":{"state":"ok","remainingPercent":0}}'
out=$(CODEX_AUTH_PPID_FIXTURE="$BASE/ppid-idle.txt" CODEX_HOME="$laneB" "$S" preflight --force 2>&1)
check "비어 있는 슬롯이 없으면 물려 있던 것을 회수한다" '[[ "$out" == *"회수한다"* ]] && [[ "$out" == *"spare"* ]] && [ "$(tok "$laneB/auth.json")" = "refresh-q1" ]'
check "codex 가 안 도는 레인은 경고 없이 회수한다" '[[ "$out" == *"codex 는 이미 종료됨"* ]]'

# 세션이 아직 떠 있으면 회수하되 **죽는다는 사실을 말한다.**
"$S" use primary --force >/dev/null 2>&1
laneB="$("$S" lane new --pid $$)"
out=$(CODEX_AUTH_PS_FIXTURE="$BASE/ps-session2.txt" CODEX_AUTH_PPID_FIXTURE="$BASE/ppid-busy.txt" CODEX_HOME="$laneB" "$S" preflight --force 2>&1)
check "떠 있는 세션에서 뺏을 때는 죽는다고 알린다" '[[ "$out" == *"회수한다"* ]] && [[ "$out" == *"세션이 떠 있다"* ]]'

# exec 배치는 절대 뺏지 않는다 — 한 레인 살리려다 아홉을 죽인다.
"$S" use primary --force >/dev/null 2>&1
laneB="$("$S" lane new --pid $$)"
out=$(CODEX_AUTH_PS_FIXTURE="$BASE/ps-exec2.txt" CODEX_AUTH_PPID_FIXTURE="$BASE/ppid-busy.txt" CODEX_HOME="$laneB" "$S" preflight --force 2>&1)
check "exec 배치 레인은 회수하지 않는다" '[[ "$out" == *"쓸 수 있는 슬롯이 없다"* ]] && [[ "$out" != *"회수한다"* ]] && [ "$(tok "$laneB/auth.json")" = "refresh-p1" ]'
check "그때 대여 중이라는 사실을 알린다" '[[ "$out" == *"대여 중"* ]]'

out=$(CODEX_AUTH_PPID_FIXTURE="$BASE/ppid-idle.txt" "$S" lane list 2>&1)
check "lane list 가 회수 가능 여부를 보여준다" '[[ "$out" == *"codex 종료됨 (회수 가능)"* ]]'
kill "$holder" 2>/dev/null; wait "$holder" 2>/dev/null
"$S" lane release --pid $$ >/dev/null 2>&1

echo "── R. CODEX_SLOT 고정 (사람이 고른 계정이 자동 전환보다 우선) ──"
"$S" use primary --force >/dev/null 2>&1
# 잔량이 0이어도 고른 계정을 그대로 쓴다 — 전환하지 않는다.
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100},"thin":{"state":"ok","remainingPercent":90}}'
laneP="$("$S" lane new --pid $$ primary)"
out=$(CODEX_HOME="$laneP" "$S" preflight --pin --force 2>&1)
check "--pin 은 소진돼도 갈아끼우지 않는다" '[[ "$out" == *"primary 고정"* ]] && [[ "$out" != *"전환:"* ]] && [ "$(tok "$laneP/auth.json")" = "refresh-p1" ]'
check "--pin 이 잔량이 없다고 경고한다" '[[ "$out" == *"잔량이 거의 없다"* ]]'

# 대여 중인 계정도 고를 수 있다 — 다만 무엇이 위험한지 말한다.
sleep 120 & rholder=$!
"$S" lane new --pid "$rholder" spare >/dev/null
laneP2="$("$S" lane new --pid $$ spare)"
out=$(CODEX_HOME="$laneP2" "$S" preflight --pin --force 2>&1)
check "대여 중인 계정도 고를 수 있다" '[[ "$out" == *"spare 고정"* ]] && [ "$(tok "$laneP2/auth.json")" = "refresh-q1" ]'
check "같이 쓰면 위험하다고 알린다" '[[ "$out" == *"토큰을 각자 회전"* ]] && [[ "$out" == *"$rholder"* ]]'
kill "$rholder" 2>/dev/null; wait "$rholder" 2>/dev/null
"$S" lane release --pid $$ >/dev/null 2>&1

# 런처가 CODEX_SLOT 을 lane 과 preflight 양쪽에 넘기는지.
L="$(dirname "$S")/dscodex.sh"
check "런처가 CODEX_SLOT 을 레인 씨앗으로 넘긴다" 'grep -q "lane new --pid .* \"\$CODEX_SLOT\"" "$L"'
# 레인 밖에서 손으로 불러도 CODEX_SLOT 을 존중해야 한다 — 아니면 엉뚱한 슬롯을 "고정" 이라 보고한다.
out=$(CODEX_SLOT=spare "$S" preflight --pin --force 2>&1)
check "레인 밖에서도 CODEX_SLOT 을 본다" '[[ "$out" == *"spare 고정"* ]] && [[ "$out" == *"레인 밖이라 보고만"* ]]'
out=$(CODEX_SLOT=nosuchslot "$S" preflight --pin --force 2>&1)
check "없는 슬롯 이름을 알려준다" '[[ "$out" == *"그런 슬롯이 없다"* ]]'
check "런처가 고정 모드로 preflight 를 부른다" 'grep -q "preflight \${CODEX_SLOT:+--pin}" "$L"'

echo "── O. dscodex 런처 ──"
L="$(dirname "$S")/dscodex.sh"
check "런처가 실행 가능하다" '[ -x "$L" ]'
out=$(bash -n "$L" 2>&1); check "런처 문법" '[ -z "$out" ]'
check "preflight 를 부른다" 'grep -q "preflight" "$L"'
check "종료 후 write-back 한다" 'grep -q "sync --quiet" "$L"'
# 한도를 문자열로 추측하던 시절의 유산이 남아 있으면 안 된다 (터미널을 깨뜨리고 디스크를 먹었다).
check "TUI 를 script 로 감싸지 않는다" '! grep -qE "^[^#]*script -qe" "$L"'

# mock codex: 1회차는 현재 슬롯을 소진시키고 실패한다. 2회차는 갈아끼운 계정과 resume 인자를 검증한다.
mkdir -p "$BASE/mock-bin"
cat > "$BASE/mock-bin/codex" <<'MOCK'
#!/usr/bin/env bash
state="${CODEX_AUTH_RESTART_STATE:?}"
fixture="${CODEX_AUTH_QUOTA_FIXTURE:?}"
count=0; [ -f "$state" ] && count="$(cat "$state")"
count=$((count + 1)); printf '%s' "$count" > "$state"
if [ "$count" -eq 1 ]; then
  case "${CODEX_AUTH_FAKE_MODE:-limit}" in
    limit)     printf '%s' '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100}}' > "$fixture"; exit 1 ;;
    interrupt) printf '%s' '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100}}' > "$fixture"; exit 130 ;;
    generic)   echo "simulated non-quota failure" >&2; exit 1 ;;
    clean)     exit 0 ;;
  esac
fi
printf '%s\n' "$*" > "$BASE_ARGS"
token="$(node -e 'console.log(JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")).tokens.refresh_token)' "$CODEX_HOME/auth.json")"
[ "$token" = "refresh-q1" ] || { echo "wrong slot: $token" >&2; exit 2; }
echo "restarted session"
MOCK
chmod +x "$BASE/mock-bin/codex"
export BASE_ARGS="$BASE/mock-args"
restart_state="$BASE/restart-count"
run_launcher() { # <fake-mode>
	: > "$restart_state"; : > "$BASE_ARGS"
	PATH="$BASE/mock-bin:$PATH" CODEX_AUTH_RESTART_STATE="$restart_state" BASE_ARGS="$BASE_ARGS" \
		CODEX_AUTH_FAKE_MODE="$1" DSCODEX_CONFIRM_SECS=0 bash "$L" 2>&1
}

# 한도 판정은 문자열이 아니라 **API 잔량**이다. 현재 슬롯이 실제로 0% 면 갈아끼우고 이어간다.
"$S" use primary --force >/dev/null 2>&1
qf '{"primary":{"state":"ok","remainingPercent":80},"spare":{"state":"ok","remainingPercent":100}}'
out=$(run_launcher limit)
check "현재 슬롯이 실제로 소진되면 갈아끼우고 재시작한다" '[ "$(cat "$restart_state")" = "2" ] && [[ "$out" == *"restarted session"* ]]'
check "이어갈 대화가 없으면 새 세션이라고 말한다" '[[ "$out" == *"새 세션을 시작한다"* ]]'

# 잔량이 남아 있으면 preflight 가 전환하지 않는다 → 재시작도 없다. 오탐이 원천적으로 불가능하다.
"$S" use primary --force >/dev/null 2>&1
qf '{"primary":{"state":"ok","remainingPercent":80},"spare":{"state":"ok","remainingPercent":100}}'
out=$(run_launcher generic)
check "쿼터가 남아 있으면 재시작하지 않는다" '[ "$(cat "$restart_state")" = "1" ] && [[ "$out" != *"restarted session"* ]]'
check "나가는 슬롯이 오염되지 않았다" '[ "$(tok "$CODEX_AUTH_DIR/primary.json")" = "refresh-p1" ]'

# 인터럽트(Ctrl+C)는 사용자가 그만두겠다고 말한 것이다. 잔량이 0이어도 재시작하지 않는다.
"$S" use primary --force >/dev/null 2>&1
qf '{"primary":{"state":"ok","remainingPercent":80},"spare":{"state":"ok","remainingPercent":100}}'
out=$(run_launcher interrupt)
check "인터럽트(130)는 소진돼도 재시작하지 않는다" '[ "$(cat "$restart_state")" = "1" ] && [[ "$out" != *"restarted session"* ]]'

# 정상 종료(/exit·/quit → rc 0)는 애초에 판정에 들어가지 않는다.
"$S" use primary --force >/dev/null 2>&1
qf '{"primary":{"state":"ok","remainingPercent":0},"spare":{"state":"ok","remainingPercent":100}}'
out=$(run_launcher clean)
check "정상 종료면 소진돼 있어도 재시작하지 않는다" '[ "$(cat "$restart_state")" = "1" ] && [[ "$out" != *"restarted session"* ]]'

# 런처는 세션이 떠 있는 동안(= codex 에서 블록된 동안) 수정될 수 있다 — 이 레포를 고치는
# 중에는 늘 그렇다. bash 는 실행 중 스크립트를 파일 오프셋으로 이어 읽으므로, 감싸지 않으면
# 세션을 닫는 순간 엉뚱한 바이트에서 파싱해 존재하지 않는 줄의 에러가 쏟아진다 (실측 2026-08-28).
check "런처 전체가 main() 안에 있다" 'grep -q "^main() {" "$L"'
check "main 호출에서 파일 읽기를 끝낸다" 'grep -q "^main .*; exit" "$L"'
probe="$BASE/edit-in-flight.sh"
cp "$L" "$probe"
( bash "$probe" >/dev/null 2>&1 & sleep 0.3; printf '# %s\n' "$(head -c 400 /dev/zero | tr "\0" "x")" >> "$probe"; wait ) 2>/dev/null
out=$(PATH="$BASE/mock-bin:$PATH" CODEX_AUTH_RESTART_STATE="$restart_state" BASE_ARGS="$BASE_ARGS" CODEX_AUTH_FAKE_MODE=clean DSCODEX_CONFIRM_SECS=0 bash "$probe" 2>&1)
check "실행 중 파일이 바뀌어도 파싱 에러가 안 난다" '[[ "$out" != *"syntax error"* ]] && [[ "$out" != *"command not found"* ]] && [[ "$out" != *"unexpected"* ]]'

# codex exec는 여러 레인이 같은 auth.json을 읽을 수 있으므로, 오류가 나도 여기서 자동 재시작하지 않는다.
"$S" use primary --force >/dev/null 2>&1
qf '{"primary":{"state":"ok","remainingPercent":80},"spare":{"state":"ok","remainingPercent":100}}'
: > "$restart_state"
out=$(PATH="$BASE/mock-bin:$PATH" CODEX_AUTH_RESTART_STATE="$restart_state" BASE_ARGS="$BASE_ARGS" CODEX_AUTH_FAKE_MODE=limit DSCODEX_CONFIRM_SECS=0 bash "$L" exec smoke 2>&1); rc=$?
check "exec 배치는 사용량 오류여도 자동 재시작하지 않는다" '[ $rc -ne 0 ] && [ "$(cat "$restart_state")" = "1" ] && [ "$(tok "$CODEX_AUTH_DIR/primary.json")" = "refresh-p1" ]'

printf '\n최종 통과 %d / 실패 %d / 건너뜀 %d\n' "$pass" "$fail" "$skipped"
[ "$fail" -eq 0 ]
rm -rf "$BASE"
[ "$fail" -eq 0 ]
